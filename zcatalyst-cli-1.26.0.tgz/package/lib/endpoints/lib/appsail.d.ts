/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { ReadStream } from 'fs';
import { IAPIOptions } from '../../internal/api';
import { TAppSailDetails } from '../../util_modules/config/lib/appsail';
export type TAppSailSignedResponse = {
    signed_url: string;
    object_key: string;
};
export type TAppSailBucketUploadOpts = {
    name: string;
    signedUrl: string;
    stream: ReadStream;
    length: number;
};
export type TSAppSailDetails = {
    type: number;
    name: string;
    stack: string;
    created_time: string;
    created_by: Record<string, string>;
    modified_time: string;
    modified_by: Record<string, string>;
    project_details: {
        project_name: string;
        id: string;
        project_type: string;
    };
    id: string;
    configuration: {
        memory: number;
        environment: Record<string, string>;
        startup_command: string;
        port: number;
    };
    status: boolean;
    url: string;
};
export default class AppSail {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    deploy(sourceFsStream: ReadStream, { stack, name, contentLength, command, memory, platform, envVariables, catalystAuth, loginRedirect, port }: {
        stack: string;
        name: string;
        contentLength: number;
        command?: string;
        memory?: number;
        platform?: string;
        envVariables?: Record<string, string>;
        catalystAuth?: boolean;
        loginRedirect?: string;
        port?: number;
    }): Promise<Record<string, unknown>>;
    getAllAppsails(): Promise<Array<TSAppSailDetails>>;
    updateConfig(appSailId: string, env: Record<string, unknown>): Promise<unknown>;
    downloadJetty(url: string): Promise<Buffer>;
    getSignedUrl(name: string): Promise<TAppSailSignedResponse>;
    uploadToBucket({ signedUrl, length, stream, name }: TAppSailBucketUploadOpts): Promise<void>;
    customAppSailCallback(target: TAppSailDetails, objectId: string): Promise<Record<string, unknown>>;
}
