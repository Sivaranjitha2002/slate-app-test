export declare function orgAPI({ auth }?: {
    auth?: boolean | undefined;
}): Promise<import("./lib/org").default>;
export declare function projectAPI({ auth, org, printError }?: {
    auth?: boolean | undefined;
    org?: string | undefined;
    printError?: boolean | undefined;
}): Promise<import("./lib/project").default>;
export declare function envAPI({ auth, org }?: {
    auth?: boolean | undefined;
    org?: string | undefined;
}): Promise<import("./lib/env").default>;
export declare function sdkAPI({ auth }?: {
    auth?: boolean | undefined;
}): Promise<import("./lib/sdk").default>;
export declare function detailsAPI(): Promise<import("./lib/catalyst-details").default>;
export declare function cacheAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/cache").default>;
export declare function filestoreAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/filestore").default>;
export declare function queueAPI({ auth, projectId, env }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
}): Promise<import("./lib/queue").default>;
export declare function zcqlAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/zcql").default>;
export declare function datastoreAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/datastore").default>;
export declare function clientAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/client").default>;
export declare function slateAPI({ auth, projectId, env }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
}): Promise<import("./lib/slate").default>;
export declare function apigAPI({ auth, projectId, env, org, printError }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
    printError?: boolean | undefined;
}): Promise<import("./lib/apig").default>;
export declare function bulkDSAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/ds-bulk").default>;
export declare function applogicAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/applogic").default>;
export declare function functionsAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/functions").default>;
export declare function eventBusAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/event-bus").default>;
export declare function logAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | number | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/log").default | undefined>;
export declare function appSailAPI({ auth, projectId, env, org }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
    org?: string | undefined;
}): Promise<import("./lib/appsail.js").default>;
export declare function zestAPI({ auth, projectId, env }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
}): Promise<import("./lib/zest.js").default>;
export declare function stratusAPI({ auth, projectId, env }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
    env?: string | undefined;
}): Promise<import("./lib/stratus").default>;
export declare function gitHubAPI(): Promise<import("./lib/git-hub").default>;
export declare function codeDeck(): Promise<import("./lib/code-deck").default>;
export declare function jobScheduling({ auth, projectId }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
}): Promise<import("./lib/job-scheduling").default>;
export declare function commonAPI(): Promise<import("./lib/common").default>;
export declare function tunnelAPI({ auth, projectId }?: {
    auth?: boolean | undefined;
    projectId?: string | undefined;
}): Promise<import("./lib/tunnel").default>;
