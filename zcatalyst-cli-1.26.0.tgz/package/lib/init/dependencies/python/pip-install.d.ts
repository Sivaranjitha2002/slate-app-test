import { asyncSpawnResposne } from '../../../util_modules/shell';
export declare function ensurePyRuntime(pth: string, stack: string, spawnCommand?: string): Promise<void>;
export declare const pypiRes: (pkg: string) => Promise<Record<string, unknown>>;
export declare function installRequirements(reqFile: string, pth: string, spawnCommand?: string, linuxMode?: boolean): Promise<void>;
export declare function installPkgs(pkgs: Array<string>, spawnCommand?: string, pth?: string | undefined): Promise<asyncSpawnResposne>;
