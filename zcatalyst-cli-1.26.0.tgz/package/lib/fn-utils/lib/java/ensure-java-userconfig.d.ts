export declare const stackVsVersions: {
    java8: {
        version: string;
        target: string;
        label: string;
    };
    java11: {
        version: string;
        target: string;
        label: string;
    };
    java17: {
        version: string;
        target: string;
        label: string;
    };
    java21: {
        version: string;
        target: string;
        label: string;
    };
    java25: {
        version: string;
        target: string;
        label: string;
    };
};
type javaProcess = 'java' | 'javac';
export declare function ensureJava(stack: string): Promise<string | void>;
export declare function getJavaSpawnCommand(process: javaProcess, binPath?: string): string;
export declare function getTargetVersion(stack: string): string;
export {};
