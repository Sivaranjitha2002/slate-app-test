import { TEMPLATE } from '../../util_modules/constants';
import { IFnTarget, NodeFn } from './common';
export declare function validate(targets: Array<IFnTarget<NodeFn>>): Promise<void>;
export declare function ensureNodeVersion(stack: string, onlyDirPath?: boolean): Promise<string>;
export declare function getTemplatePath(fnType: keyof typeof TEMPLATE.functions.node, add?: string): string;
