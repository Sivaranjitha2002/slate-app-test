import { ChildProcess } from 'child_process';
import { IServerDetails } from '../../../serve/server';
import { IFnTarget, PythonFn } from '../../../fn-utils/lib/common';
declare const _default: (fn: IServerDetails<IFnTarget<PythonFn>>, runTimePort: number) => Promise<ChildProcess>;
export default _default;
