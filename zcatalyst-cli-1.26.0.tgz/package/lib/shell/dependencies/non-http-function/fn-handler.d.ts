/// <reference types="node" />
/// <reference types="node" />
import EventEmitter from 'events';
import { IFnTarget } from '../../../fn-utils/lib/common';
import { IServerDetails } from '../../../serve/server';
import { FSWatcher } from 'chokidar';
import { ChildProcess } from 'child_process';
import { ContainerEvents } from '@zcatalyst/container-plugin/out/utils';
export declare class FnHandler {
    fn: IServerDetails<IFnTarget>;
    stack: string;
    responseFile: string;
    metaFile: string;
    closed: boolean;
    localFnEvents: EventEmitter;
    watcher?: FSWatcher;
    slave?: ChildProcess | ContainerEvents;
    constructor(fn: IServerDetails<IFnTarget>, localFnEvents: EventEmitter);
    writeResponse(response: string, status: number): void;
    responseProcessor(statusCode: number, message?: string): void;
    processFlowHandler(data: Record<string, unknown>, listenPort: number): Promise<{
        kill: () => void;
    }>;
    fnRequestHandler({ httpPort, data, accessToken }: {
        httpPort: number;
        data?: Record<string, unknown>;
        accessToken: string;
    }): Promise<void>;
    fnResponseHandler(code?: number, sig?: string): Promise<void>;
    shutdown(): Promise<void>;
    kill(): void;
}
