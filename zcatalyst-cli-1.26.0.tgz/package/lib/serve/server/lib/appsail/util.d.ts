export declare const AppsailUtils: {
    executeHook(script: string, name: string, moduleSource: string): Promise<void>;
    getVersion(stack: string): number;
    getJettyVersion(javaVersion: number): number;
    getJettyCommand(jettyPath: string, jettyVersion: string, target: string, port: number): string;
    getJettyConfig(stack: string, target: string, port: number): {
        jettyPath: string;
        jettyCommand: string;
        jettyDownloadUrl: string;
    };
};
