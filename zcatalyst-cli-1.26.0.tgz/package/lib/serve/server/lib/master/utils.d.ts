import { IncomingMessage, ServerResponse } from 'http';
import { IAPIGLocal, IAPIGRules } from '../../../../apig-utils';
import Server from 'http-proxy';
import { CatalystEventEmitter } from '../../../../util_modules/event-emitter';
export interface IMatchRule extends IAPIGRules {
    target_endpoint: string;
    source_endpoint: string;
    params: {
        [x: string]: string;
    };
}
export declare const serverEvent: CatalystEventEmitter;
export declare const removeSecure: (str: string) => string;
export declare const redirectByAuth: (req: IncomingMessage, res: ServerResponse, redirectUrl: string) => void;
export declare const createProxyServer: (port: number) => Server;
export declare const proxyResponseHandler: ({ systemRoutes, signInRedirect }: {
    systemRoutes?: IAPIGLocal | undefined;
    signInRedirect?: string | undefined;
}) => (proxyRes: IncomingMessage, req: IncomingMessage, res: ServerResponse) => void;
export declare const appsailInitJs: () => Promise<string>;
