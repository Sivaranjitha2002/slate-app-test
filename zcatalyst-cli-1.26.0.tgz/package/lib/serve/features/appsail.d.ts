import { TAppSailDetails } from '../../util_modules/config/lib/appsail';
export type TAppSailServerDetails = TAppSailDetails & {
    binPath: string;
    port: {
        appsail: {
            host: number;
            container?: number;
        };
        proxy: number;
        debug: {
            host: number;
            container?: number;
        };
    };
};
declare const _default: () => Promise<Array<TAppSailServerDetails>>;
export default _default;
