export declare const CONFIG_KEYS: {
    node12_bin: string;
    node14_bin: string;
    node16_bin: string;
    node18_bin: string;
    node20_bin: string;
    node22_bin: string;
    node24_bin: string;
    python39_bin: string;
    python310_bin: string;
    python311_bin: string;
    python312_bin: string;
    python313_bin: string;
    java8_bin: string;
    java11_bin: string;
    java17_bin: string;
    java21_bin: string;
    java25_bin: string;
    javac_disableWarnings: string;
    serve_container: string;
    functionsShell_prompt: string;
};
declare class UserConfig {
    private configFilePath;
    private config;
    private validKeys;
    constructor();
    set(key: string, value: string): Record<string, string>;
    get(key: string): string;
    delete(key: string): boolean;
    list(): string;
    has(key: string): boolean;
    refresh(): void;
}
declare const _default: UserConfig;
export default _default;
