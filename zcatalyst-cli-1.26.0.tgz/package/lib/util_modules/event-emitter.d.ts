/// <reference types="node" />
import EventEmitter from 'events';
export declare class CatalystEventEmitter extends EventEmitter {
    private listenerMap;
    on(event: string, listener: Parameters<EventEmitter['on']>[1]): this;
    once(event: string, listener: Parameters<EventEmitter['once']>[1]): this;
    removeListener(event: string, listener: Parameters<EventEmitter['on']>[1]): this;
    off(event: string, listener: Parameters<EventEmitter['off']>[1]): this;
    emit(...args: Parameters<EventEmitter['emit']>): boolean;
}
