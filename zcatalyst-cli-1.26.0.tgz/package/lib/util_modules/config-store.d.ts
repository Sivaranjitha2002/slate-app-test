export default class Store {
    private static _store;
    static changeStore(store: 'cli' | 'vscode' | 'zcode', path?: string): void;
    private static get istore();
    static get path(): string | undefined;
    static get store(): Record<string, unknown>;
    static set store(val: Record<string, unknown>);
    static set(key: string, value: unknown): void;
    static get(key: string, fallback?: unknown): unknown;
    static delete(key: string): void;
    static has(key: string): boolean;
}
