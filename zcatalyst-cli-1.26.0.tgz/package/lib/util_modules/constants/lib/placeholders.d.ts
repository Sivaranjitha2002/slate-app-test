declare const _default: Readonly<{
    client: {
        domain: string;
        package: {
            name: string;
        };
    };
    functions: {
        node_package: {
            name: string;
            main: string;
            author: string;
            dependencies: string;
        };
        java_class: string;
        java_name: string;
        python_package: {
            name: string;
            main: string;
            sdkVersion: string;
        };
    };
    catalyst_config: {
        type: string;
        stack: string;
        integ_config: string;
        integ_handlers: string;
    };
    event_data: {
        project_id: string;
        project_name: string;
        eventbus_id: string;
        eventbus_name: string;
        action: string;
        source: string;
        source_id: string;
        event_time: string;
        data: string;
        rule_id: string;
    };
    signal_event_data: {
        version: string;
        org_id: string;
        project_id: string;
        project_name: string;
        environment: string;
        uuid: string;
        source: string;
        signal_id: string;
        signal_api_name: string;
        data: string;
        time_in_ms: string;
        rule_id: string;
        target_id: string;
        attempt: string;
    };
    init_js: {
        project_id: string;
        zaid: string;
        auth_domain: string;
        org_id: string;
        stratus_domain: string;
    };
}>;
export default _default;
