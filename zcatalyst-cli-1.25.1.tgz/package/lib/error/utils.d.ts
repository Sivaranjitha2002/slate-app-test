import _runtime from '../util_modules/runtime-store';
export declare const runtime: _runtime;
