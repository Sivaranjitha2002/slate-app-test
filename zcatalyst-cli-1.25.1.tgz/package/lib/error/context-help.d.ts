export default function help(): number;
