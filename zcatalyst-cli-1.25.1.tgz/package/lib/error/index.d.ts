export interface ICatalystError {
    status?: number;
    exit?: 0 | 1 | 2;
    original?: string | Error | Array<Error>;
    context?: unknown;
    errorId?: string;
    docPath?: string;
    filePath?: string;
    arg?: Array<string>;
    skipHelp?: boolean;
}
export default class CatalystError extends Error {
    readonly status: number;
    exit: number;
    readonly original: string | undefined | Error | Array<Error>;
    context: unknown;
    errorId?: string;
    private readonly filePath?;
    arg?: Array<string>;
    skipHelp?: boolean;
    constructor(message: string, options?: ICatalystError);
    static getErrorInstance(unknownError: unknown, { message, skipHelp, docPath }?: {
        message?: string;
        skipHelp?: boolean;
        docPath?: string;
    }): CatalystError;
}
