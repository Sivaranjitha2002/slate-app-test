declare class Crypt {
    private encryptionKey;
    private cryptAlgo;
    constructor(password: string);
    decrypt(value: string): string | {
        [x: string]: unknown;
    };
    encrypt(value: unknown): string;
    isEncrypted(value: string): boolean;
    private _serialize;
    private _deserialize;
}
export default Crypt;
