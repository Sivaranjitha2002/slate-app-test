import Credential from './credential.js';
declare class Revoke {
    readonly cred: Credential;
    readonly storePath: string;
    constructor(credential: Credential, pth: string);
    _revokeToken(): Promise<unknown>;
    init(): Promise<void>;
}
export default Revoke;
