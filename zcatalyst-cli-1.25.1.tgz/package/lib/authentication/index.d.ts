export declare function create(): Promise<string>;
export declare function list(): Array<Array<string>>;
export declare function revoke(id: string): Promise<void>;
export declare function login(): Promise<void>;
export declare function logout(): Promise<void>;
