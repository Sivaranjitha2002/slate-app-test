export interface ITokenObject {
    token?: string;
    created_time?: number;
    refresh_token?: string;
    expires_at?: number;
    access_token?: string;
}
declare class Credential {
    private cToken;
    private cTime;
    private salt;
    private rToken;
    private client;
    maxExpiry: number;
    private static crypt;
    private static isTempCred;
    static globalSelf: null | Credential;
    static oneTimeToken: null | string;
    private static credentialObject;
    constructor(tokenObj: ITokenObject);
    private _getClientForSalt;
    private _getTokenObjFromStore;
    private _setTokenObjToStore;
    private _getAccessTokenFromCache;
    private _rebuildTokenCache;
    private _destroyTokenObjFromStore;
    refreshAccessToken(): Promise<ITokenObject>;
    persistMinimal(pth: string): void;
    reset(pth: string): void;
    get accessToken(): string | null;
    get refreshToken(): string;
    get cliToken(): string;
    get createdTime(): number | undefined;
    static initToken(token: string, temp?: boolean): Credential | string;
    static decrypt(token: string): ITokenObject;
    static init(token: string | ITokenObject, temp?: boolean): Credential;
    static getAccessToken(forceRefresh?: boolean): Promise<string>;
}
export default Credential;
