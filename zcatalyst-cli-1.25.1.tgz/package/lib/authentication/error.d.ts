import CatalystError, { ICatalystError } from '../error/index.js';
export default class AuthenticationError extends CatalystError {
    constructor(message: string, options: ICatalystError);
}
