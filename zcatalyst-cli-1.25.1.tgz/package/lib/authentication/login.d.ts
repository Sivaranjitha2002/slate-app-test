/// <reference types="node" />
/// <reference types="node" />
import { IncomingMessage, ServerResponse } from 'http';
import SCOPE from './constants/scopes.js';
import EventEmitter from 'events';
export interface ILoginResponse {
    user: unknown;
    token: unknown;
    scopes: Array<string>;
    dc: string;
}
export declare const missingScopes: Record<string, Array<keyof typeof SCOPE>>;
export default class Login {
    readonly localhost: boolean;
    readonly portPromise: Promise<number>;
    salt: string;
    readonly user: boolean;
    constructor(localhost?: boolean, user?: boolean);
    init(): Promise<ILoginResponse>;
    _getCallbackUrl(port: number): string;
    _getLoginUrl(callbackUrl: string, state: string): string;
    _getTokenFromAuthorizationCode(code: string, callbackUrl: string): Promise<{
        created_time: number;
        expires_at: number;
    } & Record<string, unknown>>;
    _getTokenFromDeviceCode(code: string, tkCtrl: {
        retry: boolean;
        retryCount: number;
    }): Promise<Record<string, unknown>>;
    _respondWithFile(req: IncomingMessage, res: ServerResponse, statusCode: number, filename: string): Promise<void>;
    _getUserDetails(): Promise<Record<string, unknown> | undefined>;
    static loginEvents: EventEmitter<[never]>;
    _loginWithoutLocalhost(err?: Error): Promise<{
        user: unknown;
        token: unknown;
        scopes: Array<string>;
        dc: string;
    }>;
    _loginWithLocalhost(port: number): Promise<{
        user: unknown;
        token: unknown;
        scopes: Array<string>;
        dc: string;
    }>;
    private _getScopes;
}
