interface IAUTH_Secret {
    id: string;
    secret: string;
}
export default class AUTH {
    static _web: {
        [x: string]: {
            id: string;
            secret: string;
        };
    };
    static _mobile: {
        [x: string]: {
            id: string;
            secret: string;
        };
    };
    static get web(): IAUTH_Secret;
    static get mobile(): IAUTH_Secret;
}
export {};
