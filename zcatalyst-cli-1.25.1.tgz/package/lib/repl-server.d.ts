/// <reference types="node" />
import { REPLServer } from 'repl';
declare class Repl {
    prompt: string;
    writer: (output: unknown) => string;
    useColors: boolean;
    ignoreUndefined: boolean;
    server: null | REPLServer;
    context: Array<{
        command: string;
        exe: unknown;
    }>;
    paused: boolean;
    closed: boolean;
    pureEmit: (event: string | symbol, ...args: Array<any>) => boolean;
    constructor({ prompt, writer, useColors, ignoreUndefined }?: {
        prompt?: string | undefined;
        writer?: ((output: unknown) => string) | undefined;
        useColors?: boolean | undefined;
        ignoreUndefined?: boolean | undefined;
    });
    start(): Repl;
    emit(eventName: string, ...inputs: Array<any>): boolean;
    showPrompt(): void;
    setContext(command: string, exe: unknown): Repl;
    close(): void;
    pause(): void;
    resume(): void;
    wait(): Promise<void>;
    write(str?: string): void;
}
export default Repl;
