export declare function filterPorts(): void;
export declare function filterTargets({ pathSense, target }?: {
    pathSense?: boolean;
    target?: 'functions';
}): Array<string>;
