import { ISlateConfig } from '../../util_modules/config/lib/slate';
export type TSlateServerDetails = ISlateConfig & {
    port: {
        slate: number;
        proxy: number;
    };
    trigger: {
        kill: boolean;
    };
};
declare const _default: () => Promise<Array<TSlateServerDetails>>;
export default _default;
