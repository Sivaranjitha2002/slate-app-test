import { TAppSailDetails } from '../../util_modules/config/lib/appsail';
export type TAppSailServerDetails = TAppSailDetails & {
    port: {
        appsail: {
            host: number;
            container?: number;
        };
        proxy: number;
        debug: {
            host: number;
            container?: number;
        };
    };
};
declare const _default: () => Promise<Array<TAppSailServerDetails>>;
export default _default;
