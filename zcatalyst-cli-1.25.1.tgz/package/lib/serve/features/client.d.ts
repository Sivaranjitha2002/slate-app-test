declare const _default: () => Promise<Record<string, unknown>>;
export default _default;
