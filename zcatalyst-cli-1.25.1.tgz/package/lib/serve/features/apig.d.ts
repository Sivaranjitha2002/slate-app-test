import { IAPIGLocal } from '../../apig-utils';
declare const _default: () => Promise<IAPIGLocal | undefined>;
export default _default;
