import { IFnTarget } from '../../fn-utils/lib/common.js';
import { TAppSailServerDetails } from './appsail.js';
import { TSlateServerDetails } from './slate.js';
export declare function client(): Promise<void>;
export declare function functions(): Promise<Array<IFnTarget>>;
export declare function apig(): Promise<void>;
export declare function appsail(): Promise<Array<TAppSailServerDetails>>;
export declare function slate(): Promise<Array<TSlateServerDetails>>;
