/// <reference types="node" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { EventEmitter } from 'events';
import { IFnTarget } from '../../fn-utils/lib/common';
import type { IClientTarget } from './lib/web_client/types';
import { TAppSailServerDetails } from '../features/appsail';
import { TSlateServerDetails } from '../features/slate';
export interface IServerDetails<T = IFnTarget | IClientTarget | TAppSailServerDetails | TSlateServerDetails> {
    type: 'client' | 'server' | 'functions' | 'appsail' | 'slate';
    target: T;
    httpPort: T extends IFnTarget | IClientTarget ? number : undefined;
    debugPort: T extends IFnTarget ? number : undefined;
    process?: ChildProcess | EventEmitter;
    isAlive: boolean | null;
    restarting: boolean;
}
export type TServerTargets = {
    functions: Array<IServerDetails<IFnTarget>>;
    server: Array<IServerDetails<IFnTarget>>;
    client: Array<IServerDetails<IClientTarget>>;
    appSail: Array<IServerDetails<TAppSailServerDetails>>;
    slate: Array<IServerDetails<TSlateServerDetails>>;
};
declare class Server {
    private targetsMap;
    private masterServer?;
    private _addBasicFnDetails;
    add(type: 'client' | 'server' | 'appsail' | 'functions' | 'slate', target: IFnTarget | TAppSailServerDetails | IClientTarget | TSlateServerDetails): void;
    private startServer;
    start(): Promise<void>;
    wait(): Promise<void>;
    private kill;
    restart(target: IServerDetails<IFnTarget>): Promise<void>;
    stop(): Promise<void>;
}
export default Server;
