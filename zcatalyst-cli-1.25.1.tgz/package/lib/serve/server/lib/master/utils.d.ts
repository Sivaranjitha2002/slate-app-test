/// <reference types="node" />
import { IncomingMessage, ServerResponse } from 'http';
import { IAPIGLocal, IAPIGRules } from '../../../../apig-utils';
import Server from 'http-proxy';
import EventEmitter from 'events';
export interface IMatchRule extends IAPIGRules {
    target_endpoint: string;
    source_endpoint: string;
    params: {
        [x: string]: string;
    };
}
declare class ServerEvent extends EventEmitter {
}
export declare const serverEvent: ServerEvent;
export declare const removeSecure: (str: string) => string;
export declare const redirectByAuth: (req: IncomingMessage, res: ServerResponse, redirectUrl: string) => void;
export declare const createProxyServer: (port: number) => Server;
export declare const proxyResponseHandler: ({ systemRoutes, signInRedirect }: {
    systemRoutes?: IAPIGLocal | undefined;
    signInRedirect?: string | undefined;
}) => (proxyRes: IncomingMessage, req: IncomingMessage, res: ServerResponse) => void;
export declare const appsailInitJs: () => Promise<string>;
export {};
