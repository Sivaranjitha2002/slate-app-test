import Server from 'http-proxy';
import { IServerDetails } from '../..';
import { Express, Request, Response } from 'express';
import { TAppSailServerDetails } from '../../../features/appsail';
export declare function addAppSailRoutes(app: Express, details: IServerDetails<TAppSailServerDetails>, proxy: Server, unknownProxy: (req: Request, res: Response) => void): void;
