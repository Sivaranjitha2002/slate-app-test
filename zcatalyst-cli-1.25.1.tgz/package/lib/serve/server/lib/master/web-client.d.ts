import { Express, Request, Response } from 'express';
import { IServerDetails } from '../..';
import { IClientTarget } from '../web_client/types';
import Server from 'http-proxy';
export declare function addWebClientRoutes(app: Express, details: IServerDetails<IClientTarget>, proxy: Server, unknownProxy: (req: Request, res: Response) => void): void;
