import Server from 'http-proxy';
import { IServerDetails } from '../..';
import { Express, Request, Response } from 'express';
import { TSlateServerDetails } from '../../../features/slate';
export declare function addSlateRoutes(app: Express, details: IServerDetails<TSlateServerDetails>, proxy: Server, unknownProxy: (req: Request, res: Response) => void): void;
