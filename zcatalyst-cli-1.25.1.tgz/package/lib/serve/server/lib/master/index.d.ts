/// <reference types="node" />
import { Server } from 'http';
import { IServerDetails, TServerTargets } from '../../index';
import { TAppSailServerDetails } from '../../../features/appsail';
import { TSlateServerDetails } from '../../../features/slate';
export default function spinUpMaster(listenPort: number, { otherServerDetails, appSailDetails, slateDetails }: {
    otherServerDetails?: Partial<TServerTargets>;
    appSailDetails?: IServerDetails<TAppSailServerDetails>;
    slateDetails?: IServerDetails<TSlateServerDetails>;
}): Promise<Server>;
