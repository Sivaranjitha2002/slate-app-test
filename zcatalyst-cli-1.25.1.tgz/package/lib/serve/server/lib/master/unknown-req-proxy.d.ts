import express from 'express';
import Server from 'http-proxy';
declare const _default: (proxyInstance: Server, masterPort: number, customProxyUrl?: string) => (req: express.Request, res: express.Response) => void;
export default _default;
