import { Express } from 'express';
import { IServerDetails } from '../..';
import Server from 'http-proxy';
import { IFnTarget } from '../../../../fn-utils/lib/common';
export declare function addFnRoutes(app: Express, details: IServerDetails<IFnTarget>, proxy: Server): void;
