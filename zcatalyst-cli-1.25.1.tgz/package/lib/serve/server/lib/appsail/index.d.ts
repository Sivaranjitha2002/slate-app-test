import { ChildProcess } from 'child_process';
import { TAppSailServerDetails } from '../../../features/appsail';
import { IServerDetails } from '../..';
import { ContainerEvents } from '@zcatalyst/container-plugin';
declare const _default: (serverDetails: IServerDetails<TAppSailServerDetails>) => Promise<ChildProcess | ContainerEvents>;
export default _default;
