/// <reference types="node" />
import { EventEmitter } from 'events';
export default function slateServer(httpPort: number, source: string, { homepage, enableWatch, notFoundPage }?: {
    homepage?: string;
    enableWatch?: boolean;
    notFoundPage?: string;
}): Promise<EventEmitter>;
