import { ChildProcess } from 'child_process';
import { IServerDetails } from '../..';
import { TSlateServerDetails } from '../../../features/slate';
import EventEmitter from 'events';
declare const _default: (serverDetails: IServerDetails<TSlateServerDetails>) => Promise<ChildProcess | EventEmitter>;
export default _default;
