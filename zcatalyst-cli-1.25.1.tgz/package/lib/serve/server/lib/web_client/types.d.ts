export interface IClientTarget {
    name: string;
    homepage: string;
    source: string;
    login_redirect: string;
    package_json: string;
    valid: boolean;
    plugins?: Record<string, unknown>;
    notFoundPage: string;
    local_url?: string;
    opts?: {
        open: boolean;
        watch: boolean;
    };
}
