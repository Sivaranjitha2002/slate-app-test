import type { IServerDetails } from '../../index.js';
import type { IClientTarget } from './types';
import type { EventEmitter } from 'events';
declare const _default: (details: IServerDetails<IClientTarget>, masterPort: number) => Promise<EventEmitter>;
export default _default;
