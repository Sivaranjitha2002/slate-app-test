/// <reference types="node" />
import { EventEmitter } from 'events';
export default function webClientServer(httpPort: number, source: string, { homepage, enableWatch, notFoundPage }?: {
    homepage?: string;
    enableWatch?: boolean;
    notFoundPage?: string;
}): Promise<EventEmitter>;
