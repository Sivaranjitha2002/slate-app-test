import { ChildProcess } from 'child_process';
import { IServerDetails } from '../..';
import { IFnTarget } from '../../../../fn-utils/lib/common';
import { ContainerEvents } from '@zcatalyst/container-plugin';
declare const _default: (details: IServerDetails<IFnTarget>) => Promise<ChildProcess | ContainerEvents>;
export default _default;
