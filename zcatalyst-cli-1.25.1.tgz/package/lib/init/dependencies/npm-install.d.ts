import { asyncSpawnResposne } from '../../util_modules/shell';
declare const _default: (pth: string, skipPrompt?: boolean) => Promise<asyncSpawnResposne | Array<asyncSpawnResposne> | undefined>;
export default _default;
