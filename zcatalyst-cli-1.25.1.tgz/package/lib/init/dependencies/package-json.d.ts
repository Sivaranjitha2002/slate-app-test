declare const _default: (keys: Array<string>) => Promise<Record<string, string>>;
export default _default;
