import { asyncSpawnResposne } from '../../../util_modules/shell';
declare const _default: (pth: string, stack: string, isIntegFn?: boolean, integService?: string | boolean) => Promise<asyncSpawnResposne | Array<asyncSpawnResposne> | void>;
export default _default;
export declare function ensurePyRuntime(pth: string, stack: string): Promise<void>;
export declare const pypiRes: (pkg: string) => Promise<Record<string, unknown>>;
export declare function installRequirements(reqFile: string, pth: string, stackVersion: string, linuxMode?: boolean): Promise<void>;
export declare function installPkgs(pkgs: Array<string>, stackVersion: string, pth?: string | undefined): Promise<asyncSpawnResposne>;
