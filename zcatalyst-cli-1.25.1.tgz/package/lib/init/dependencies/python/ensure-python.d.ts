export declare function ensurePython(version: string, fallBackNeeded: boolean, skipHelp: boolean): Promise<void>;
export declare function ensurePythonWithPip(version: string, fallBackNeeded?: boolean, skipHelp?: boolean): Promise<void>;
