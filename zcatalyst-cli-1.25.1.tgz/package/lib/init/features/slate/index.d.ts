declare const _default: (add?: boolean) => Promise<void>;
export default _default;
