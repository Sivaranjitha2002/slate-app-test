export declare function setCatalystConfig(featureName: 'functions' | 'client' | 'apig' | 'appsail' | 'slate', add?: boolean): void;
export declare function functions(add?: boolean): Promise<void>;
export declare function client(): Promise<void>;
export declare function slate(add?: boolean): Promise<void>;
export declare function project(): Promise<void>;
export declare function appsail(): Promise<void>;
declare const _default: {
    functions: typeof functions;
    client: typeof client;
    project: typeof project;
    appsail: typeof appsail;
    slate: typeof slate;
};
export default _default;
