export interface IFnProjectTemplate {
    type: string;
    name: string;
    properties: {
        stack: string;
        code: {
            path: string;
        };
        configuration: {
            memory: number;
        };
        type: string;
        name: string;
    };
}
declare const _default: () => Promise<void>;
export default _default;
