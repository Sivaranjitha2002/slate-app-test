declare const _default: (stack: string) => () => Promise<string | undefined>;
export default _default;
