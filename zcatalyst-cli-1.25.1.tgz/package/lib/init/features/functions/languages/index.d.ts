declare const _default: {
    node: (stack: string) => () => Promise<string | undefined>;
    java: (stack: string) => () => Promise<string | undefined>;
    python: (stack: string) => () => Promise<string | undefined>;
};
export default _default;
