export interface IClientProjectTemplate {
    type: string;
    name: string;
    properties: {
        app_name: string;
        code: {
            path: string;
        };
    };
}
