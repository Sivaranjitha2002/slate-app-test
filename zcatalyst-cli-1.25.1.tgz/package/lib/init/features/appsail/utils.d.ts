export type _TAppSailInitConfig = {
    source: string;
    build?: string;
    stack?: {
        runtime: string;
        lang: string;
    };
    command?: string;
    scripts?: Record<string, string>;
    memory?: number;
    platform?: 'javase' | 'war';
};
export declare function getAppSailZip(): Promise<_TAppSailInitConfig>;
export declare function getAppSailName(): Promise<string>;
export declare function getContainerImageTag(): Promise<string>;
export declare function getCustomAppSailSource(): Promise<string>;
