export declare const fillClientInitPayload: (source: string, name: string) => void;
export declare function directoryOverridePrompt(dir: string): Promise<void>;
export declare function clientNamePrompt(question: string, defaultAns: string): Promise<string>;
export declare function addDependency(filePath: string, dep: Record<string, string>): Promise<void>;
export declare function addDependency(filePath: string, dep: Record<string, string>, { dev, depPath }: {
    dev?: boolean;
    depPath?: Array<string>;
}): Promise<void>;
