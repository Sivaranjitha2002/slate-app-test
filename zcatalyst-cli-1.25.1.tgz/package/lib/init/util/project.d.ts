import { ICatalystOrgObj } from '../../endpoints/lib/org';
import { IProjectServerObj } from '../../util_modules/project';
export declare const fillProjectPayload: (selectedOrg: ICatalystOrgObj, selectedProject: IProjectServerObj, isNew?: boolean, isImport?: boolean) => Promise<void>;
