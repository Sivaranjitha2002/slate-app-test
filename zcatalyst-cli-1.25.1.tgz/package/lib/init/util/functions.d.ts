export interface IFnInitDetails {
    source: string;
    name: string;
    stack: string;
    type: string;
}
export declare const fillFunctionsInitPayload: (source: string, name: string, stack: string, type: string) => void;
