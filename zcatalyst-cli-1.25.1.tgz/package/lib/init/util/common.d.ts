import { IRuntime } from '../../fn-utils/lib/common.js';
import { IChoice, TSeparator } from '../../prompt/index.js';
import { REMOTE_REF } from '../../util_modules/constants/index.js';
export declare function getRuntimeDetails(fnType?: keyof typeof REMOTE_REF.functions.type): Promise<IRuntime>;
export declare function getRuntimeChoices({ fnType, runtimeDetails }: {
    fnType?: keyof typeof REMOTE_REF.functions.type;
    runtimeDetails?: IRuntime;
}): Promise<Array<IChoice | TSeparator>>;
export declare function getRuntimePromptAnswer(question: string, fnType?: keyof typeof REMOTE_REF.functions.type): Promise<{
    runtime: string;
    lang: 'node' | 'java';
}>;
