/// <reference types="node" />
/// <reference types="node" />
export type CodeDeckDetails = {
    category: string;
    title: string;
    description: {
        short: string;
        long: string;
    };
    github: {
        url: string;
    };
};
export type CodeDeckTokenDetails = [importId: string, gitUrl: string];
export declare function listenDeploy(id: string, gitUrl: string): Promise<boolean>;
export declare function getTemplateFile(deckZip: Buffer): Promise<string | undefined>;
export declare function getDeckFromGit(): Promise<CodeDeckDetails>;
export declare class CodeDeckToken {
    static createToken(importId: string, gitUrl: string): string;
    static getDetailsFromToken(token: string): CodeDeckTokenDetails;
}
