import { ReadStream } from 'fs-extra';
import { ISlateConfig } from './util_modules/config/lib/slate';
export declare const slateUtils: {
    validate: (source: string) => Promise<void>;
    getSlateFilters(targetStr: string): Array<string>;
    filterTargets(allTargets: Array<ISlateConfig>): Array<ISlateConfig>;
    pack: (source?: string) => Promise<{
        stream: ReadStream;
        length: number;
    }>;
};
export declare function validateServeCommand(targDetails: Array<ISlateConfig>): Array<ISlateConfig>;
