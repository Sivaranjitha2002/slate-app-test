import { labeled } from '../util_modules/logger';
export type paddedLogTarget = {
    label: string;
    message: string;
    logType: keyof ReturnType<typeof labeled>;
};
export declare const logPaddedLabels: (logs: Array<paddedLogTarget | string>, padLeft?: string) => void;
