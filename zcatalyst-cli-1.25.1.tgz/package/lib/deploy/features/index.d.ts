declare const _default: {
    functions: () => Promise<void>;
    client: () => Promise<void>;
    slate: () => Promise<void>;
    apig: () => Promise<void>;
    appsail: (standAlone: boolean) => Promise<void>;
};
export default _default;
