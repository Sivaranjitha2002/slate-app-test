import { IFnTarget, JavaFn, NodeFn, PythonFn } from '../../../../fn-utils/lib/common';
export declare function node(targets: Array<IFnTarget<NodeFn>>): Promise<Array<IFnTarget<NodeFn>> | void>;
export declare function java(targets: Array<IFnTarget<JavaFn>>): Promise<Array<IFnTarget<JavaFn>> | void>;
export declare function python(targets: Array<IFnTarget<PythonFn>>): Promise<Array<IFnTarget<PythonFn>> | void>;
