export declare const fnLogger: () => void;
