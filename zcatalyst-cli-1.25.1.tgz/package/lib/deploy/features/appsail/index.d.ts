export declare function executeHook(script: string, name: string, moduleSource: string): Promise<void>;
declare const _default: (standAlone?: boolean) => Promise<void>;
export default _default;
