/// <reference types="node" />
import { ReadStream, Stats } from 'fs';
import { TAppSailDetails } from '../../../util_modules/config/lib/appsail';
export declare function packCustomAppSail(_targ: TAppSailDetails): Promise<{
    stream: ReadStream;
    tmpFile: Stats & {
        path: string;
        cleanup: boolean;
    };
}>;
export declare function packAppSail(_targ: TAppSailDetails): Promise<{
    stream: ReadStream;
    length: number;
}>;
