import { IRuntime } from '../../../fn-utils/lib/common';
import { IAppSailServerConfig, TAppSailDetails } from '../../../util_modules/config/lib/appsail';
export declare function validateOptions<T>(validationFn: (...args: Array<unknown>) => Promise<T | false>, option: string, ...args: Array<unknown>): Promise<T | boolean>;
export declare function validateBuildPath(path: string): Promise<string | false>;
export declare function validateStack(stack: string, stackPromise: Promise<IRuntime>): Promise<{
    runtime: string;
    lang?: string;
} | false>;
export declare function validatePlatform(platform: string, stack: {
    lang: string;
    runtime: string;
}): Promise<string | false>;
export declare function urlLogger(): Array<TAppSailDetails>;
export declare function getConfigJsonInputs(): Promise<IAppSailServerConfig>;
export declare function getStandAloneTarget(): Promise<TAppSailDetails>;
