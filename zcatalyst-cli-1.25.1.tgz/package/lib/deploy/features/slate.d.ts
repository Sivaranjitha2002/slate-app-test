import { ISlateConfig } from '../../util_modules/config/lib/slate';
declare const _default: () => Promise<void>;
export default _default;
export declare function getEnvironmentType(): string;
export declare function slateLogger(): Array<ISlateConfig>;
