import CatalystError from '../error/index.js';
declare function deploy({ feature, error }?: {
    feature?: string;
    error?: Array<CatalystError>;
}): Promise<Array<CatalystError>>;
export default deploy;
