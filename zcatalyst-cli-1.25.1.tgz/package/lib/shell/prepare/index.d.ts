import { IFnTarget } from '../../fn-utils/lib/common';
import { REMOTE_REF } from '../../util_modules/constants';
declare const _default: (fnTypes: Array<keyof typeof REMOTE_REF.functions.type>, skipFnFilter?: boolean) => Promise<Array<IFnTarget>>;
export default _default;
