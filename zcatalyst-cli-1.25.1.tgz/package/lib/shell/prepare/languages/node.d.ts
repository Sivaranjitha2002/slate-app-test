import { IFnTarget, NodeFn } from '../../../fn-utils/lib/common';
declare const _default: (targets?: Array<IFnTarget<NodeFn>>) => Promise<Array<IFnTarget<NodeFn>> | undefined>;
export default _default;
