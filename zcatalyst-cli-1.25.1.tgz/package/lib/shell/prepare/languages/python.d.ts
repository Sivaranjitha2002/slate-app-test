import { IFnTarget, PythonFn } from '../../../fn-utils/lib/common';
declare const _default: (targets?: Array<IFnTarget<PythonFn>>) => Promise<Array<IFnTarget<PythonFn>> | undefined>;
export default _default;
