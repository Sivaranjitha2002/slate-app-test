import { IFnTarget, JavaFn, NodeFn, PythonFn } from '../../../fn-utils/lib/common';
export declare function prepareFunctions(targets: Array<IFnTarget>): Promise<[
    Array<IFnTarget<NodeFn>> | undefined,
    Array<IFnTarget<JavaFn>> | undefined,
    Array<IFnTarget<PythonFn>> | undefined
]>;
