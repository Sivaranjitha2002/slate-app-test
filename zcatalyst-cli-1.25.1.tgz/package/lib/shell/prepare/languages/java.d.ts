import { IFnTarget, JavaFn } from '../../../fn-utils/lib/common';
declare const _default: (targets?: Array<IFnTarget<JavaFn>>) => Promise<Array<IFnTarget<JavaFn>> | undefined>;
export default _default;
