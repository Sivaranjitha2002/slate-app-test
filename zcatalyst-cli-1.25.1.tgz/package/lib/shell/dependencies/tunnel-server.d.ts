import express from 'express';
import Repl from '../../repl-server';
import LocalFunction from './non-http-function';
type TTunnelData = {
    function_data: Record<string, unknown>;
    function_details: {
        project_id: string;
        function_name: string;
        function_id: string;
        function_type: 'cron' | 'event' | 'job' | 'integration';
    };
    default: Record<string, unknown>;
};
export default class TunnelServer {
    #private;
    constructor(repel: Repl);
    isAsyncFn(fnType: TTunnelData['function_details']['function_type']): boolean;
    send(req: express.Request, res: express.Response, status?: number, data?: string, contentType?: string): Promise<void>;
    startServer(): Promise<void>;
    addContext(name: string, target: LocalFunction): this;
    stopServer(): Promise<void>;
}
export {};
