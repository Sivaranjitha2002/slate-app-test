/// <reference types="node" />
/// <reference types="node" />
import queue from 'better-queue';
import { ChildProcess } from 'child_process';
import express from 'express';
import http from 'http';
import { IFnTarget } from '../../fn-utils/lib/common';
import Repl from '../../repl-server';
import { ConnectionDestroyer } from '../../util_modules/server';
export declare const checkIfRuntimeServerRunning: (port: string, itr?: number) => Promise<boolean>;
declare class HttpFunctions {
    repl: Repl | undefined;
    app: express.Application;
    nodeInvoker: {
        [x: string]: string;
    };
    javaInvoker: {
        [x: string]: string;
    };
    requestFile: string;
    responseFile: string;
    metaFile: string;
    runningSlaves: Array<ChildProcess>;
    q: queue<unknown, unknown>;
    targets: Array<IFnTarget>;
    connDestroyer?: ConnectionDestroyer;
    constructor({ repl, primary }?: {
        repl?: Repl;
        primary?: boolean;
    });
    _spinUpServer(): Promise<http.Server>;
    start(): Promise<http.Server>;
    stop(): Promise<void>;
}
export default HttpFunctions;
