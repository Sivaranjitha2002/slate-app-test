import { ChildProcess } from 'child_process';
import { IServerDetails } from '../../../serve/server';
import { IFnTarget } from '../../../fn-utils/lib/common';
declare const _default: (fn: IServerDetails<IFnTarget>, data: string, { slaveFnTarget, accessToken }: {
    slaveFnTarget: Record<string, string>;
    accessToken: string;
}) => ChildProcess;
export default _default;
