import { ChildProcess } from 'child_process';
import { IFnTarget } from '../../../fn-utils/lib/common';
import { IServerDetails } from '../../../serve/server';
declare const _default: (fn: IServerDetails<IFnTarget>, data: string, { javaInvoker, slaveFnTarget, accessToken }: {
    javaInvoker: string;
    slaveFnTarget: Record<string, string>;
    accessToken: string;
}) => ChildProcess;
export default _default;
