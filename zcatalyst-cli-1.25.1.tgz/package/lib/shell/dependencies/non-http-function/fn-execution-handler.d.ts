/// <reference types="node" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { IFnTarget } from '../../../fn-utils/lib/common';
import { IServerDetails } from '../../../serve/server';
import { FnHandler } from './fn-handler';
import { EventEmitter } from 'stream';
import { ContainerEvents } from '@zcatalyst/container-plugin';
export declare class FnExecutionHandler extends FnHandler {
    constructor(serverDetails: IServerDetails<IFnTarget>, localFnEvents: EventEmitter);
    execute(data: Record<string, unknown>, accessToken: string): Promise<ChildProcess>;
    executeWithContainer(data: Record<string, unknown>, accessToken: string): Promise<ContainerEvents>;
}
