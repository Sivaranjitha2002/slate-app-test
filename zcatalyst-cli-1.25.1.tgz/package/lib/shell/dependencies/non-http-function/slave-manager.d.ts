/// <reference types="node" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import CatalystError from '../../../error';
import { IServerDetails } from '../../../serve/server';
import { IFnTarget } from '../../../fn-utils/lib/common';
import { FSWatcher } from 'chokidar';
import { EventEmitter } from 'stream';
import Repl from '../../../repl-server';
import { ContainerEvents } from '@zcatalyst/container-plugin';
import { FnExecutionHandler } from './fn-execution-handler';
export declare class SlaveManager extends FnExecutionHandler {
    repl: Repl;
    killed: boolean;
    javaInvoker?: string;
    watcher?: FSWatcher;
    isContainer: boolean;
    slave?: ChildProcess | ContainerEvents;
    constructor(fn: IServerDetails<IFnTarget>, repl: Repl, localFnEvents: EventEmitter);
    call: (shell?: boolean) => (rawData?: string | {
        [x: string]: unknown;
    }) => CatalystError | Promise<ChildProcess | ContainerEvents>;
}
