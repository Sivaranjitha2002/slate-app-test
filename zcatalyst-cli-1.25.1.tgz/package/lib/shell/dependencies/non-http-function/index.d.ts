import { IFnTarget } from '../../../fn-utils/lib/common';
import Repl from '../../../repl-server';
import { SlaveManager } from './slave-manager';
import { IServerDetails } from '../../../serve/server';
export default class NonHttpFunction {
    repl: Repl;
    fn: IServerDetails<IFnTarget>;
    slaveManager: SlaveManager;
    call: (shell?: boolean) => (data?: Record<string, unknown>) => unknown;
    private localFnEvents;
    constructor(repl: Repl, target: IFnTarget);
    once(event: 'response', fn: (response: {
        Status?: number;
        status?: number;
        ContentType?: string;
        responseBody: string;
    }) => void): this;
    once(event: 'error', fn: (error: Error) => void): this;
    removeListener(event: 'response' | 'error', fn: (...args: Array<any>) => unknown): this;
}
