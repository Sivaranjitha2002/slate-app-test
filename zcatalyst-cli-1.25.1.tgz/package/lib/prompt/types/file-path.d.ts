/// <reference types="node" />
import InquirerAutocomplete from 'inquirer-autocomplete-prompt';
import { Answers } from 'inquirer';
import { Interface } from 'readline';
export default class InquirerFilePath extends InquirerAutocomplete<Answers> {
    nbChoices: unknown;
    answer: unknown;
    answerName: unknown;
    shortAnswer: unknown;
    done?: (val: string) => void;
    constructor(question: {
        rootPath: string;
        pattern: string;
        exclude: Array<string>;
        default: string;
        ignoreFiles?: boolean;
        excludeDir?: boolean;
        empTxt?: string;
        depth?: number;
    }, rl: Interface, answers: Answers);
    search(searchTerm: string): Promise<void>;
    onSubmitAfterValidation(line: string): Promise<void>;
    private checkValidationResult;
    onSubmit(line: string): Promise<void>;
}
