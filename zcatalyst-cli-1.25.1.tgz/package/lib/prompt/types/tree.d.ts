/// <reference types="node" />
import { Answers } from 'inquirer';
import BasePrompt from 'inquirer/lib/prompts/base.js';
import Paginator from 'inquirer/lib/utils/paginator.js';
import { Interface } from 'readline';
export interface TreeData<T = unknown> {
    display: string;
    expand?: string;
    value: T;
    short: string;
}
declare enum ETreeState {
    OPEN = 1,
    CLOSED = 2,
    EXPANDED = 3
}
export declare class TreeNode {
    #private;
    root?: string;
    open: boolean;
    leaves: Array<(TreeData & {
        isExpanded: boolean;
    }) | TreeNode>;
    activeIdx: number;
    prevActiveIdx: number;
    nodes: string[];
    level: number;
    get indent(): number;
    constructor(root?: string);
    addNode(node: TreeData | TreeNode): this;
    buildTree({ paginator, force }?: {
        paginator?: Paginator;
        force?: boolean;
    }): string;
    expandNode(display: string, expand: string): string;
    openTree(strict?: boolean): ETreeState;
    closeTree(): void;
    moveActive(distance?: number): void;
    getValue(): TreeData;
    wrapLine(line: string, indent: number): string;
}
export default class InquirerTree extends BasePrompt {
    paginator: Paginator;
    done?: (val: unknown) => void;
    treeOpts: {
        pageSize: number;
        multiple: boolean;
        loop: boolean;
    };
    message: string;
    choices: TreeNode;
    constructor(question: {
        message: string;
        name: string;
        treeChoices: Array<TreeNode | TreeData>;
    }, rl: Interface, answers: Answers);
    protected _run(callback: (...args: Array<unknown>) => void): this;
    bindKeyEvents(): void;
    constructTree(): void;
    render({ answer, error }?: {
        answer?: TreeData;
        error?: string | Error;
    }): void;
}
export {};
