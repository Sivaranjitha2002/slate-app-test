/// <reference types="node" />
import inquirer, { Answers, Question } from 'inquirer';
import Choice from 'inquirer/lib/objects/choice';
import Choices from 'inquirer/lib/objects/choices';
import Separator from 'inquirer/lib/objects/separator';
import Base from 'inquirer/lib/prompts/base';
import { Interface as ReadLineInterface } from 'readline';
type SearchBoxPlusPromptOptions<T extends Answers = any> = Question<T> & {
    highlight?: boolean;
    searchable?: boolean;
    defaults?: Array<string>;
    notFoundMsg?: string;
    searchMsg?: string;
    pageSize: number;
    source: (answersSoFar: Answers, input: string | undefined) => Promise<Array<unknown>>;
    boxType: 'check-box' | 'list';
};
export default class SearchBox<TAnswers extends Answers = Answers> extends Base<SearchBoxPlusPromptOptions & {
    states: unknown;
}> {
    private pointer;
    private paginator;
    private boxType;
    private choices;
    private checkedChoices;
    private searching;
    private lastQuery?;
    private default?;
    private value;
    private lastSourcePromise?;
    private done?;
    constructor(questions: Question & SearchBoxPlusPromptOptions & {
        states: unknown;
    }, rl: ReadLineInterface, answers: Answers);
    _run(callback: SearchBox<TAnswers>['done']): this;
    getValue(choice: Choice<TAnswers> | Separator): string | undefined;
    executeSource(): Promise<unknown>;
    render({ answer, error }?: {
        answer?: Array<Choice> | Choice;
        error?: Error | string;
    }): void;
    onEnd(state: inquirer.prompts.SuccessfulPromptStateData | inquirer.prompts.FailedPromptStateData): void;
    onError(state: inquirer.prompts.FailedPromptStateData): void;
    getCurrentValue(): Array<unknown> | unknown;
    onUpKey(): void;
    onDownKey(): void;
    onNumberKey(input: any): void;
    onSpaceKey(): void;
    onAllKey(): void;
    onInverseKey(): void;
    onKeypress(): void;
    toggleChoice(choice: Choice<Answers> | Separator, nextChecked?: boolean): void;
    static getCheckboxFigure(checked?: boolean): string;
    renderChoices(choices: Choices<TAnswers>, pointer: number, checkBox?: boolean): string;
}
export {};
