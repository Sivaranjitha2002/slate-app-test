/// <reference types="node" />
import { Answers, ListQuestionOptions } from 'inquirer';
import Choices from 'inquirer/lib/objects/choices';
import ListPrompt from 'inquirer/lib/prompts/list.js';
import { Interface } from 'readline';
export interface IWithDescQuestion extends Omit<ListQuestionOptions, 'type'> {
    description: string;
    type: 'with-desc';
}
export default class InquirerPromptWithDescription extends ListPrompt {
    question: IWithDescQuestion;
    constructor(question: IWithDescQuestion, rl: Interface, answers: Answers);
    protected render(): void;
    listRender(choices: Choices, pointer: number): string | void;
}
