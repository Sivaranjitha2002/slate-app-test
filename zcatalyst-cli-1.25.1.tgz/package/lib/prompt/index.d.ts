import inquirer from 'inquirer';
import Separator from 'inquirer/lib/objects/separator';
import PromptUI from 'inquirer/lib/ui/prompt';
import { TreeData, TreeNode } from './types/tree';
export interface IChoice extends inquirer.ChoiceOptions, inquirer.ListChoiceOptions, inquirer.CheckboxChoiceOptions {
    id?: string;
}
export interface IQuestion extends inquirer.Question, inquirer.ListQuestionOptions {
    name: string;
    type?: inquirer.QuestionTypeName | 'file-path' | 'tree' | 'search-box' | 'with-desc';
    defaultAns?: unknown;
    choices?: Array<IChoice | TSeparator> | Array<string | TSeparator>;
    treeChoices?: Array<TreeNode | TreeData>;
    rootPath?: string;
    exclude?: Array<string>;
    excludeDir?: boolean;
    ignoreFiles?: boolean;
    depth?: number;
    empTxt?: string;
    validatingText?: string;
    description?: string;
}
export type TSeparator = Separator;
declare const _default: {
    register: (type: 'file-path' | 'tree' | 'search-box' | 'with-desc') => Promise<void>;
    deregister: (type: 'file-path' | 'tree' | 'search-box') => void;
    separator: (line: string) => TSeparator;
    choice: (name: string, { id, value, short, disabled, checked, ...otherOpts }?: IChoice) => IChoice;
    ask: (...questions: Array<IQuestion>) => (Promise<inquirer.Answers> & {
        ui: PromptUI;
    }) | Promise<inquirer.Answers>;
    question: (name: string, question: string, { type, defaultAns, choices, validate, filter, when, prefix, suffix, ...otheropts }?: Omit<IQuestion, 'name'>) => IQuestion;
};
export default _default;
