import { Command } from 'commander';
import CatalystError from './error/index.js';
export declare class Client {
    private _cli;
    private load;
    get cli(): Command;
    constructor(program: Command);
    init(command?: string): Promise<Array<unknown> | unknown>;
    processArgs(...args: Array<string>): Promise<Command>;
    getCommand(name: string): Command | null;
    getAllCommandNames(): Array<string>;
    private convertOptions;
    exec(command: string, projectRoot: string, cwd: string, { args, options, inputs }?: {
        args?: Array<string>;
        options?: Record<string, string | boolean | Array<string>>;
        inputs?: Record<string, unknown>;
    }): Promise<{
        exitCode: 0 | 1 | 2;
        error?: CatalystError;
    }>;
}
