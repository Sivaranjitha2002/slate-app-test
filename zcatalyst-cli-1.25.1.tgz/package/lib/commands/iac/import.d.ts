import Archiver from '../../archiver';
import { IIacResponse } from '../../endpoints/lib/iac';
import command from '../../internal/command';
export declare const iacImport: (filePath?: string, projectName?: string) => Promise<[Archiver, string, IIacResponse]>;
declare const _default: command;
export default _default;
