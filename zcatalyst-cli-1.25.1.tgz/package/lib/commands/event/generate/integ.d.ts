import Command from '../../../internal/command';
declare const _default: Command;
export default _default;
