import command from '../../../internal/command';
export interface ZestSourceConfig {
    resources: Array<{
        id: string;
    }>;
    stack: string;
    name: string;
    with_dependency?: boolean;
    config?: {
        base_package?: string;
    };
}
declare const _default: command;
export default _default;
