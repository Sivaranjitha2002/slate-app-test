import command from '../../internal/command';
interface IAPIGScheduleStatus {
    success_count: number;
    fail_count: number;
    fail_details: Array<{
        [x: string]: string;
    }>;
}
export interface IAPIGScheduleReport {
    state: number;
    total?: number;
    create?: IAPIGScheduleStatus;
    update?: IAPIGScheduleStatus;
    delete?: IAPIGScheduleStatus;
    error?: string;
}
declare const _default: command;
export default _default;
