import command from '../internal/command';
declare const _default: command;
export default _default;
