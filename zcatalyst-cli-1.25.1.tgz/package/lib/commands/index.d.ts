import { Client } from '../client';
export declare function loadCommand(client: Client, name: string): Promise<((...args: Array<string>) => Promise<unknown>) | void>;
export declare function loadAllCommands(client: Client): Promise<Array<unknown>>;
