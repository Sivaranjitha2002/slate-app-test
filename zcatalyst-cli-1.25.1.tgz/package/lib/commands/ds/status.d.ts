import command from '../../internal/command';
interface IBulkDSStatus {
    rows_processed?: number;
    fail_count?: number;
}
export interface IBulkDBReport {
    job_id: string;
    status: string;
    results?: {
        download_url?: string;
        description: string;
    };
}
export interface ICumulativeReport {
    [x: string]: {
        read?: IBulkDSStatus | null;
        insert?: IBulkDSStatus | null;
        update?: IBulkDSStatus | null;
        upsert?: IBulkDSStatus | null;
    };
}
declare const _default: command;
export default _default;
