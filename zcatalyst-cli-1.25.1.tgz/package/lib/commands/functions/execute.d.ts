import Command from '../../internal/command.js';
declare const _default: Command;
export default _default;
