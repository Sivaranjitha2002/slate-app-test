import { ReadStream } from 'fs-extra';
export declare const clientUtils: {
    validate: ({ source, skipPluginValidation }?: {
        source?: string | undefined;
        skipPluginValidation?: boolean | undefined;
    }) => Promise<Record<string, unknown>>;
    executeHook: ({ prefix, command }: {
        prefix: 'pre' | 'post';
        command: string;
    }) => Promise<void>;
    pack: () => Promise<{
        stream: ReadStream;
        length: number;
    }>;
    deleteClientLocal: (path: string) => Promise<void>;
};
