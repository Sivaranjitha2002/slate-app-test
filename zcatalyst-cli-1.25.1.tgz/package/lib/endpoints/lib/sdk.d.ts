/// <reference types="node" />
/// <reference types="node" />
import { IAPIOptions } from '../../internal/api';
declare class SDK {
    opts: IAPIOptions;
    constructor(opts: IAPIOptions);
    getSdkUrl(fnType: string, service?: string): string;
    java(fnType: string, service?: string): Promise<Buffer>;
}
export default SDK;
