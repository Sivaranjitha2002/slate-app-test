import { IAPIOptions } from '../../internal/api';
declare class ZCQL {
    opts: IAPIOptions & {
        env?: string;
    };
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    query(query: string): Promise<unknown>;
}
export default ZCQL;
