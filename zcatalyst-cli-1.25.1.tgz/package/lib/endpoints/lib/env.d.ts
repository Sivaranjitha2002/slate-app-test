import { IAPIOptions } from '../../internal/api';
declare class Env {
    opts: IAPIOptions;
    envId: string | undefined;
    constructor(opts: IAPIOptions, org?: string);
    getEnvs(projectId: string, throwErr?: boolean): Promise<unknown>;
}
export default Env;
