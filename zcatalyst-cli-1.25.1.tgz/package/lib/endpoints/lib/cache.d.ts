import { IAPIOptions } from '../../internal/api';
declare class Cache {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllSegments(): Promise<unknown>;
    put(key: string, value: string, segmentId?: string): Promise<unknown>;
    get(name: string, segmentId?: string): Promise<unknown>;
}
export default Cache;
