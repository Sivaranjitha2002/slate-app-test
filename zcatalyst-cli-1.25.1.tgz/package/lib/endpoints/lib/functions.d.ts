/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
declare class Functions {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllFunctions(type?: string): Promise<unknown>;
    getFunction(fnId: string): Promise<unknown>;
    updateConfig(functionId: string, env: Record<string, unknown>): Promise<unknown>;
    deploy(sourceFsStream: ReadStream | undefined, { stack, name, type, memory, envVariables, contentLength }: {
        stack: string;
        name: string;
        type: string;
        contentLength?: number;
        memory?: number;
        envVariables?: Record<string, unknown>;
    }): Promise<unknown>;
    download(functionId: string): Promise<unknown>;
    delete(functionId: string): Promise<unknown>;
}
export default Functions;
