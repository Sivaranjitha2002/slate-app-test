import { IAPIOptions } from '../../internal/api';
declare class Queue {
    opts: IAPIOptions & {
        env?: string;
    };
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllTopics(): Promise<unknown>;
    produce(data: unknown, topicId: string): Promise<unknown>;
    consume(topicId: string): Promise<unknown>;
}
export default Queue;
