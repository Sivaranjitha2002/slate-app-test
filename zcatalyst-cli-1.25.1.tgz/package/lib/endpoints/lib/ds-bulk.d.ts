import { IAPIOptions } from '../../internal/api';
export interface IDSBulkCallback {
    url: string;
    method: string;
}
export interface IDSBulkReadConfig {
    table_identifier?: string | number;
    callback?: IDSBulkCallback;
    query?: {
        page?: string | number;
        select_columns?: Array<string>;
        criteria?: {
            [x: string]: unknown;
        };
    };
}
export interface IDSBulkWriteConfig {
    table_identifier?: string | number;
    callback?: IDSBulkCallback;
    object_details?: {
        bucket_name?: string;
        object_key?: string;
        version_id?: string;
    };
    file_id?: number | string;
    operation?: string;
    find_by?: string;
    fk_mapping?: Array<{
        [columnName: string]: string;
    }>;
}
declare class BulkDS {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    private postData;
    read(table: string, config?: IDSBulkReadConfig): Promise<unknown>;
    write(table: string, config?: IDSBulkWriteConfig): Promise<unknown>;
    getStatus(operation: 'read' | 'write', jobid: string, prev?: boolean): Promise<unknown>;
    getReport(operation: 'read' | 'write', jobid: string): Promise<unknown>;
    getAllJobs(operation: 'read' | 'write'): Promise<unknown>;
    downloadReport(url: string, fileName: string): Promise<unknown>;
}
export default BulkDS;
