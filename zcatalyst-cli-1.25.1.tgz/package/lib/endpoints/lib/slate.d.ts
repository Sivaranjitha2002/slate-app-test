/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
import { FrameworkType, ISlateAppInfo } from '../../util_modules/config/lib/slate';
declare class Slate {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getFrameworks(): Promise<Array<FrameworkType>>;
    getAllApps(): Promise<Array<ISlateAppInfo>>;
    downloadTemplate(): Promise<unknown>;
    deploy(sourceStream: ReadStream, contentLength: number, appName: string, deploymentName?: string, appId?: string, config?: string, msg?: string): Promise<unknown>;
}
export default Slate;
