/// <reference types="node" />
import type { IncomingHttpHeaders } from 'http';
import { IAPIOptions } from '../../internal/api';
import { IProjectServerObj } from '../../util_modules/project';
export interface IProjectUser {
    email_id: string;
    user_id: string;
    display_name: string;
}
declare class ProjectAPI {
    opts: IAPIOptions;
    constructor(opts: IAPIOptions, org?: string);
    getProject(projectId: string): Promise<IProjectServerObj>;
    getAllProjects(): Promise<Array<IProjectServerObj>>;
    createProject(name: string): Promise<IProjectServerObj>;
    getCurrentProjectUser(projectId: string, headers?: IncomingHttpHeaders): Promise<IProjectUser | null>;
}
export default ProjectAPI;
