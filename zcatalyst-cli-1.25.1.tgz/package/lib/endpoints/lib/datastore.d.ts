import { IAPIOptions } from '../../internal/api';
declare class Datastore {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllTables(): Promise<unknown>;
    getColumnDetails(tableId: string): Promise<unknown>;
}
export default Datastore;
