/// <reference types="node" />
/// <reference types="node" />
import { IAPIOptions } from '../../internal/api';
export default class Project {
    opts: IAPIOptions;
    constructor();
    getUserThumb(id: string): Promise<Buffer>;
}
