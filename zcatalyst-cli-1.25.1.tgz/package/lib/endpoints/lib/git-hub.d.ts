/// <reference types="node" />
/// <reference types="node" />
import { IAPIOptions } from '../../internal/api';
export default class GitHub {
    opts: IAPIOptions & {
        isExternal: boolean;
    };
    constructor();
    private getGitHubLatestRelease;
    private getLatestZipUrl;
    appsailNodejs(): Promise<unknown>;
    appsailJava(): Promise<unknown>;
    appsailPython(): Promise<unknown>;
    validateUrl(url: string): Promise<unknown>;
    download(url: string, title?: string | null): Promise<Buffer | undefined>;
}
