/// <reference types="node" />
import { ReadStream } from 'fs';
import { IAPIOptions } from '../../internal/api';
declare class Applogic {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    deploy(sourceFsStream: ReadStream | undefined, { stack, name, memory, envVariables, contentLength }: {
        stack: string;
        name: string;
        memory?: number;
        envVariables?: Record<string, unknown>;
        contentLength?: number;
    }): Promise<unknown>;
    getAllApplogic(): Promise<unknown>;
    download(name: string): Promise<unknown>;
    delete(id: string): Promise<unknown>;
}
export default Applogic;
