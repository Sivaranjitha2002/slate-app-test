/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
declare class Client {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    deploy(sourceStream: ReadStream, contentLength: number): Promise<unknown>;
    getAllHistory(): Promise<unknown>;
    getWebappDetails(): Promise<unknown>;
    download(historyId: string): Promise<unknown>;
    delete(historyId: string): Promise<unknown>;
}
export default Client;
