import { IAPIOptions } from '../../internal/api';
export interface ICatalystJobpoolDetails {
    type: 'Function';
    name: string;
    created_by: {
        zuid: string;
        is_confirmed: boolean;
        email_id: string;
        first_name: string;
        last_name: string;
        user_type: string;
        user_id: string;
    };
    created_time: string;
    modified_by: {
        zuid: string;
        is_confirmed: boolean;
        email_id: string;
        first_name: string;
        last_name: string;
        user_type: string;
        user_id: string;
    };
    modified_time: string;
    capacity: {
        memory: number;
    };
    project_details: {
        project_name: string;
        id: string;
        project_type: string;
    };
    id: string;
}
export default class JobScheduling {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getJobpoolDetails(id: string): Promise<ICatalystJobpoolDetails>;
    getJobpoolDetails(): Promise<Array<ICatalystJobpoolDetails>>;
}
