/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
declare class Stratus {
    opts: IAPIOptions & {
        env?: string;
    };
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllBuckets(): Promise<unknown>;
    uploadObject(bucketName: string, objectName: string, fileStream: ReadStream): Promise<unknown>;
}
export default Stratus;
