import { IAPIOptions } from '../../internal/api';
declare class EventBus {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllEventBusDetails(): Promise<unknown>;
}
export default EventBus;
