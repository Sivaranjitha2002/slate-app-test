import { IAPIOptions } from '../../internal/api';
export interface ICatalystOrgObj {
    name: string;
    url: string;
    id: string;
    is_default: boolean;
}
declare class OrgAPI {
    opts: IAPIOptions;
    constructor(opts: IAPIOptions);
    getAllOrgs(): Promise<Array<ICatalystOrgObj>>;
}
export default OrgAPI;
