import { IAPIOptions } from '../../internal/api';
declare class Log {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    log(logsArr: Array<unknown>): Promise<unknown>;
}
export default Log;
