import { IAPIOptions } from '../../internal/api';
export interface SpecificationParams {
    version?: string;
    page?: number;
    per_page?: number;
    sort_by?: string;
    filters?: string;
}
export interface SpecificationRes {
    specifications: Array<{
        xml: string;
        id: string;
        name: string;
        product: {
            id: string;
            name: string;
        };
        version: string;
        visibility: string;
        created_by: {
            id: string;
            name: string;
        };
        created_time: string;
        modified_by: {
            id: string;
            name: string;
        };
        modified_time: string;
    }>;
    info: {
        more_records?: boolean;
        count?: number;
        page?: number;
        per_page?: number;
    };
}
export interface ScheduledJobRes {
    scheduled_jobs: [
        {
            id: string;
            status: string;
            action: string;
            action_info: {
                ids: Array<string>;
                version: string;
                file_id: string;
                failure_reason: string;
            };
            created_by: {
                id: string;
                name: string;
            };
            created_time: string;
            start_time: string;
            end_time: string;
        }
    ];
}
declare class Zest {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
        isExternal: boolean;
    });
    getSpecifications(query?: SpecificationParams): Promise<unknown>;
    generateFunction(resources: Array<object>, specEnv: string, name: string): Promise<unknown>;
    generateAppsail(requestJson: unknown): Promise<unknown>;
    getScheduledJob(job_id: string): Promise<unknown>;
    getFile(file_id: string, source: string, name: string): Promise<unknown>;
}
export default Zest;
