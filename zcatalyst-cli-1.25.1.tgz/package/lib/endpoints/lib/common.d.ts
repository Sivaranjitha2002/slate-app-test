/// <reference types="node" />
/// <reference types="node" />
export default class Common {
    download(url: string, title?: string): Promise<Buffer>;
}
