import { CodeDeckDetails } from '../../code-deck';
import { IAPIOptions } from '../../internal/api';
type CodeDeckResponse = Record<string, CodeDeckDetails>;
export default class CodeDeck {
    #private;
    opts: IAPIOptions;
    constructor(opts: IAPIOptions);
    data(): Promise<CodeDeckResponse>;
}
export {};
