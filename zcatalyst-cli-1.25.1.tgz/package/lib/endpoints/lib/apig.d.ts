/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
declare class Apig {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    private getRules;
    deploy(sourceStream: ReadStream): Promise<unknown>;
    getAllRules(): Promise<unknown>;
    getAPIGStatus(): Promise<unknown>;
    getScheduleReport(prev?: boolean): Promise<unknown>;
    updateAPIGStatus(status: boolean): Promise<unknown>;
}
export default Apig;
