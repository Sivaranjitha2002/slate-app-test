/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
interface IIacLog {
    error_message: string;
    component: string;
}
export interface IIacResponse {
    id: string;
    project_details: {
        project_name: string;
        id: string;
        project_type: string;
    };
    action_details: {
        template_name?: string;
        template_type: string;
    };
    status: string;
    logs?: {
        processing_errors?: IIacLog;
        validation_errors?: Array<string>;
    };
}
declare class IacAPI {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId?: string, opts?: IAPIOptions & {
        env: string;
    });
    deploy(projectName: string, format: string, file: ReadStream, schedule?: boolean): Promise<IIacResponse>;
    update(file: ReadStream): Promise<IIacResponse>;
    bundle(format: string): Promise<IIacResponse>;
    bundleStatus(): Promise<IIacResponse>;
    bundleDownload(): Promise<Buffer>;
    allDeploys(): Promise<Array<IIacResponse>>;
    deployStatus(importId: string): Promise<IIacResponse>;
    deployDelete(importId: string): Promise<IIacResponse>;
    deployDownload(importId: string): Promise<Buffer>;
}
export default IacAPI;
