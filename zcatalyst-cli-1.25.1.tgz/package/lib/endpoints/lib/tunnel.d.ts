import { IAPIOptions } from '../../internal/api';
type TUserDetails = {
    zuid: string;
    is_confirmed: boolean;
    email_id: string;
    first_name: string;
    last_name: string;
    user_type: string;
    user_id: string;
};
export type TTunnelDetails = {
    project_id: {
        project_name: string;
        id: string;
        project_type: string;
    };
    tunnel_url: string;
    tunnel_status: 'Enabled' | 'Disabled';
    created_by: TUserDetails;
    enabled_time: string;
    modified_by: TUserDetails;
    modified_time: string;
    function_details: Array<{
        name: string;
        type: string;
        id: string;
    }>;
};
export default class TunnelAPI {
    projectId: string;
    opts: IAPIOptions;
    constructor(projectId: string, opts: IAPIOptions);
    getTunnel(): Promise<TTunnelDetails>;
    enableTunnel(tunnelUrl?: string): Promise<Record<string, unknown>>;
    disableTunnel(): Promise<Record<string, unknown>>;
    tunnelCallback(status: string | number, details: Record<string, unknown>, data?: string): Promise<void>;
}
export {};
