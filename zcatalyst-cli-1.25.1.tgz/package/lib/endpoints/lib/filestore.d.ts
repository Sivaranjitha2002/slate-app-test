/// <reference types="node" />
import { ReadStream } from 'fs-extra';
import { IAPIOptions } from '../../internal/api';
declare class Filestore {
    opts: IAPIOptions;
    projectId: string;
    constructor(projectId: string, opts: IAPIOptions & {
        env?: string;
    });
    getAllFolders(): Promise<unknown>;
    uploadFile(folderId: string | string, fileStream: ReadStream): Promise<unknown>;
}
export default Filestore;
