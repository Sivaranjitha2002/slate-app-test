import { IRuntime } from '../../fn-utils/lib/common';
import { IAPIOptions } from '../../internal/api';
declare class CatalystDetailsAPI {
    private opts?;
    constructor(opts?: IAPIOptions);
    getDetails<T = IRuntime>(feature: string, fnType?: string): Promise<T>;
}
export default CatalystDetailsAPI;
