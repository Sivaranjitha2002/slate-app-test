import request = require('request');
import catalystError from './error';
declare const _default: (response: request.Response, body: unknown, skipHelp?: boolean) => catalystError;
export default _default;
