import _runtime from './util_modules/runtime-store';
declare const _default: _runtime;
export default _default;
