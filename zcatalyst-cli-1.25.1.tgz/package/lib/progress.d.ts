import Throbber from './throbber';
export interface IProgress {
    title?: string;
    fillChar?: string;
    bgChar?: string;
    startingChar?: string;
    endingChar?: string;
    total?: number;
    failure?: (err?: string | Error) => string;
    progressType?: 'upload' | 'download';
}
export default class Progress {
    title: string;
    fillChar: string;
    bgChar: string;
    startingChar: string;
    endingChar: string;
    total: number;
    throbber: Throbber;
    startTime: [number, number];
    currentProgress: number;
    currentProgressFrame: string;
    failure?: (err?: string | Error) => string;
    progressType: IProgress['progressType'];
    constructor({ title, fillChar, bgChar, startingChar, endingChar, total, failure, progressType }?: IProgress);
    private get MAX_SCREEN_LENGTH();
    private get barLength();
    private getCompleteness;
    private fillProgress;
    private fillSpace;
    private updateProgress;
    error(err?: string | Error): void;
    tick(count?: number): void;
}
