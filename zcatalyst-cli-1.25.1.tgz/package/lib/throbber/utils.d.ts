/// <reference types="node" />
export type VALID_STATUSES = 'succeed' | 'fail' | 'spinning' | 'non-spinnable' | 'stopped';
export type VALID_COLORS = 'black' | 'red' | 'green' | 'yellow' | 'blue' | 'magenta' | 'cyan' | 'white' | 'grey' | 'redBright' | 'greenBright' | 'yellowBright' | 'blueBright' | 'magentaBright' | 'cyanBright' | 'whiteBright';
export interface ISpinnerOptions {
    text?: string;
    status?: VALID_STATUSES;
    indent?: number;
    spinner?: {
        interval: number;
        frames: Array<string>;
    };
    succeedPrefix?: string;
    failPrefix?: string;
    color?: VALID_COLORS;
    succeedColor?: VALID_COLORS;
    failColor?: VALID_COLORS;
    spinnerColor?: VALID_COLORS;
    disableSpins?: boolean;
}
export declare function breakText(text: string, prefixLength: number): string;
export declare function getLinesLength(text: string, prefixLength: number): Array<number>;
export declare function writeStream(stream: NodeJS.WritableStream, output: string, rawLines: Array<number>): void;
export declare function cleanStream(stream: NodeJS.WritableStream, rawLines: Array<number>): void;
