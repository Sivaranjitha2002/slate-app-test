/// <reference types="node" />
/// <reference types="node" />
import { ISpinnerOptions, VALID_STATUSES } from './utils';
import { TTYPassThrough } from '../util_modules/logger';
interface IThrobbers {
    [name: string]: ISpinnerOptions;
}
declare class Throbber {
    options: ISpinnerOptions;
    spinners: IThrobbers;
    isCursorHidden: boolean;
    currentInterval: null | NodeJS.Timeout;
    stream: NodeJS.WriteStream | TTYPassThrough;
    lineCount: number;
    currentFrameIndex: number;
    spin: boolean;
    private constructor();
    static instance?: Throbber | undefined;
    static getInstance(options?: ISpinnerOptions): Throbber;
    pick(name: string): ISpinnerOptions;
    add(name: string, options?: ISpinnerOptions): ISpinnerOptions;
    update(name: string, options?: ISpinnerOptions): ISpinnerOptions;
    succeed(name: string, options?: ISpinnerOptions): ISpinnerOptions;
    fail(name: string, options?: ISpinnerOptions): ISpinnerOptions;
    remove(name: string): ISpinnerOptions;
    stopAll(newStatus?: string): IThrobbers;
    hasActiveSpinners(): boolean;
    setSpinnerProperties(name: string, options: ISpinnerOptions, status?: VALID_STATUSES): void;
    updateSpinnerState(): void;
    loopStream(): NodeJS.Timeout;
    setStreamOutput(frame?: string): void;
    setRawStreamOutput(): void;
    checkIfActiveSpinners(): void;
    bindSigint(): void;
}
export default Throbber;
