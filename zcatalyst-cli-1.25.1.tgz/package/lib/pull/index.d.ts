declare function pull(): Promise<void>;
export default pull;
