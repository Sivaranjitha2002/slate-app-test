declare const _default: {
    functions: () => Promise<void>;
    client: () => Promise<void>;
    apig: () => Promise<void>;
};
export default _default;
