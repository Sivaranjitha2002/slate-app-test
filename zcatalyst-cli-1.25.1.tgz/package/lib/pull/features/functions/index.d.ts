declare const _default: (_fns?: Array<string>) => Promise<void>;
export default _default;
