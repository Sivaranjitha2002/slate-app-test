import { IFnTarget, JavaFn, NodeFn, PythonFn } from '../../../fn-utils/lib/common';
export declare function node(target: IFnTarget<NodeFn>): Promise<void>;
export declare function java(target: IFnTarget<JavaFn>): Promise<void>;
export declare function python(target: IFnTarget<PythonFn>): Promise<void>;
