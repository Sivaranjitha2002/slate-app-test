declare const _default: (inScopes?: Array<string>) => void;
export default _default;
