declare const _default: ({ optional }?: {
    optional?: boolean | undefined;
}) => Promise<void>;
export default _default;
