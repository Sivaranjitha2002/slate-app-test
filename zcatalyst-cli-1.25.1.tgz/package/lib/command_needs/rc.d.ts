declare const _default: ({ optional, resolveOnNotFound, skipOrgCheck, skipProjectCheck, generateRc }?: {
    optional?: boolean | undefined;
    resolveOnNotFound?: boolean | undefined;
    skipOrgCheck?: boolean | undefined;
    skipProjectCheck?: boolean | undefined;
    generateRc?: boolean | undefined;
}) => Promise<void>;
export default _default;
