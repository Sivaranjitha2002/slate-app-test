import express from 'express';
import { IServerDetails } from '../serve/server';
import { TAppSailServerDetails } from '../serve/features/appsail';
declare const _default: (appSailDetails?: IServerDetails<TAppSailServerDetails>) => (req: express.Request, _RES: express.Response, next: express.NextFunction) => void;
export default _default;
