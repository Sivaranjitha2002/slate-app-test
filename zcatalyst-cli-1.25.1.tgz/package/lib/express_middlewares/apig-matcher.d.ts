import express from 'express';
declare const _default: (_REQ: express.Request, res: express.Response, next: express.NextFunction) => void;
export default _default;
