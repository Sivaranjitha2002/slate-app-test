import express from 'express';
declare const _default: (err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => void;
export default _default;
