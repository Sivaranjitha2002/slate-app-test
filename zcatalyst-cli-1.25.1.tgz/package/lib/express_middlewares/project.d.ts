import express from 'express';
import { IProjectCliObj } from '../util_modules/project';
declare const _default: (projectObj: Pick<IProjectCliObj, 'id' | 'domain_prefix' | 'key' | 'env_name'> & {
    domain: string;
}) => (req: express.Request, _RES: express.Response, next: express.NextFunction) => void;
export default _default;
