import express from 'express';
declare const _default: (req: express.Request, _RES: express.Response, next: (err?: Error) => void) => Promise<void>;
export default _default;
