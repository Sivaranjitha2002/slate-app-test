import express from 'express';
declare const _default: (req: express.Request, _RES: express.Response, next: express.NextFunction) => void;
export default _default;
