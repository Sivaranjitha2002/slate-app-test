export declare function integHelper(services: Array<string>): Promise<void>;
export declare function copyIntegHandlers(templatePath: string, targetPath: string, lang: string): Promise<void>;
