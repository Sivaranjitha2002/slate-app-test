/// <reference types="node" />
import { FSWatcher } from 'chokidar';
import { ReadStream } from 'fs-extra';
import LocalFunction from '../../shell/dependencies/non-http-function';
import { REMOTE_REF } from '../../util_modules/constants';
export interface IRuntime {
    eol_runtimes?: Record<string, number>;
    runtimes: Array<string>;
}
export interface JavaFn {
    compilerOut: {
        warning: Array<string>;
        error: Array<string>;
    };
    binPath?: string;
}
export interface PythonFn {
    binPath: string;
    debug?: {
        port: number;
        debugger: 'debugpy';
    };
}
export interface NodeFn {
    binPath: string;
}
export interface IFnTarget<T = JavaFn | PythonFn | NodeFn> {
    name: string;
    id?: string;
    source: string;
    build: string;
    valid: boolean;
    failure_reason?: string | Error;
    stack?: string;
    type?: keyof typeof REMOTE_REF.functions.type;
    index?: string;
    zip_stream?: {
        stream: ReadStream;
        length: number;
    };
    url?: string;
    url_with_id?: string;
    local_url?: string;
    watcher?: FSWatcher;
    localFn?: LocalFunction;
    integ_config?: Array<{
        service: string;
        handlers?: Record<string, string>;
    }>;
    env_var?: Record<string, unknown>;
    plugins?: {
        serve: {
            name?: string;
            source?: string;
        };
    };
    inputs?: string | Record<string, unknown>;
    memory?: number;
    additionalInfo?: T;
}
export declare function validate(skipFnFilter?: boolean): Promise<Array<string>>;
export declare function refineTargets(rawTargets?: Array<string>, mapRemoteFn?: boolean): Promise<Array<IFnTarget>>;
export declare function executeHook({ prefix, command }: {
    prefix: 'pre' | 'post';
    command: string;
}): Promise<void>;
export declare function pack(target: IFnTarget): Promise<void>;
export declare function generateUrlForTarget(target: IFnTarget): string | void;
export declare function findAndReplaceConfigProps(dir: string, { stack, type, integ_config, integ_handler }: {
    stack: string;
    type: keyof typeof REMOTE_REF.functions.type;
    integ_config: string;
    integ_handler: string;
}): Promise<void>;
export declare function resolveAllFnPorts(targets?: Array<IFnTarget>): Promise<void>;
export declare function deleteFunctionLocal(path: string): Promise<void>;
export declare function getSDK(fnType: string, dest: string, stack: 'java', options?: {
    service?: string;
}): Promise<void>;
export declare function updateFnConfig(target: {
    [x: string]: unknown;
}): Promise<void>;
export declare function copyModDirPerm(src: string, dest: string, perm: string, { replace }?: {
    replace?: boolean | undefined;
}): Promise<void>;
