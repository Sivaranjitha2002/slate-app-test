import { IFnTarget, JavaFn } from '../common';
export declare const warningMessages: Array<string>;
export declare function compileTarget(target: IFnTarget<JavaFn>): Promise<void>;
export declare function printCompilationLog(javaFns: Array<IFnTarget<JavaFn>>): void;
