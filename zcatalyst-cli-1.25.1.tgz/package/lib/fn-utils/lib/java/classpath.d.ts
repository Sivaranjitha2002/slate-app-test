export declare function rewriteClasspath(pth: string, libPth: string): Promise<void>;
export declare function normaliseClasspath(pth: string, libFolder: string): Promise<void>;
