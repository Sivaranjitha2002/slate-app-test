export declare const keywords: readonly string[];
export declare function containsKeyWord(name: string): boolean;
