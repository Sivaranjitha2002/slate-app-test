/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { TEMPLATE } from '../../../util_modules/constants/index.js';
import { IFnTarget, JavaFn } from '../common.js';
export { FN_TYPE } from '../../../util_modules/constants/index.js';
export declare const classPathSep: string;
export declare function isValidClassName(name: string): boolean;
export declare function ensureJavaInvoker(pth: string, invoker: string, target: IFnTarget<JavaFn>): boolean;
export declare function projectFileValidation(pth: string, target: IFnTarget): Promise<void>;
export declare function extractAllData(child: ChildProcess, name: 'stderr' | 'stdout'): Promise<string>;
export declare function validate(targets: Array<IFnTarget<JavaFn>>): Promise<void>;
export declare function getTemplatePath(fnType: keyof typeof TEMPLATE.functions.java, add?: string): string;
export * from './classpath';
export * from './compile';
export * from './ensure-java-userconfig.js';
export * from './keywords';
