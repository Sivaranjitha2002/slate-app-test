export declare function getBrowserLogicFramework(stack: string): Promise<string>;
export declare function downloadJavaDependencies(path: string, deps: Array<string>, isZip?: boolean): Promise<Array<void>>;
