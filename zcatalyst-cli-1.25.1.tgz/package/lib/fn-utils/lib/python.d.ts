import { IFnTarget, PythonFn } from './common';
export declare function validate(targets: Array<IFnTarget<PythonFn>>): Promise<void>;
export declare function removeRequirements(reqFile: string, target: IFnTarget): Promise<void>;
