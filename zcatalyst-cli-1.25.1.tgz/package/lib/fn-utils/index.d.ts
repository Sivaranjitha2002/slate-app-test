import * as common from './lib/common';
import * as java from './lib/java';
import * as node from './lib/node';
import * as python from './lib/python';
export declare const fnUtils: {
    node: typeof node;
    java: typeof java;
    python: typeof python;
    common: typeof common;
};
