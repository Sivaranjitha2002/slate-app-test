import { Client } from './client';
export declare const Catalyst: Client;
