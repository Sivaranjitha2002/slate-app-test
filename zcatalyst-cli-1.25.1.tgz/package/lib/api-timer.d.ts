/// <reference types="node" />
import EventEmitter from 'events';
export default class APITimer extends EventEmitter {
    private apiFn;
    private frequency;
    private interval;
    private maxErrors;
    execCount: number;
    ended: boolean;
    errorCount: number;
    constructor(apiFn: () => Promise<unknown>, frequency?: number, errorTolerance?: number);
    emit(eventName: string | symbol, ...args: Array<any>): boolean;
    waitForEnd(): Promise<unknown>;
    fire(): Promise<void>;
    start(): this;
    end(e?: Error, data?: unknown): void;
}
