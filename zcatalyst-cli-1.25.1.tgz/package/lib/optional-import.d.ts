declare const _default: <T>(name: string, source: string) => Promise<T | undefined>;
export default _default;
