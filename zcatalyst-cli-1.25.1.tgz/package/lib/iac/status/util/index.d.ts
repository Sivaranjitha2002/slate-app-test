import { IIacResponse } from '../../../endpoints/lib/iac';
export declare const getSpinnerTxt: (type: 'bundle' | 'deploy' | 'codedeck') => (deployDetails: IIacResponse, status?: string) => string;
