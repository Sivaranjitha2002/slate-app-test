import { ReadStream } from 'fs-extra';
export type IAPIGMethods = 'get' | 'put' | 'patch' | 'post' | 'delete' | 'all';
export type IAPIGAuth = Array<'APIKey' | 'OAuth' | 'CatalystUserManagement'>;
export interface IAPIGRules {
    api_id?: string;
    name: string;
    source_endpoint: string;
    target_endpoint?: string;
    target?: 'client' | 'basicio' | 'advancedio';
    method: 'GET' | 'PUT' | 'PATCH' | 'POST' | 'DELETE' | 'ANY';
    throttling?: {
        overall: {
            [x: string]: string;
        };
        ip: {
            [x: string]: string;
        };
    };
    target_id?: string;
    created_by?: unknown;
    created_time?: unknown;
    modified_by?: unknown;
    modified_time?: unknown;
    authentication?: IAPIGAuth | null;
    system?: boolean;
    status?: boolean;
}
export type IAPIGLocal = {
    [sourceUrl: string]: {
        [method in IAPIGMethods]: Omit<IAPIGRules, 'source_endpoint' | 'method'>;
    };
};
export declare const apigUtils: {
    validate: () => Promise<Array<IAPIGRules>>;
    compile: (ruleArr: Array<IAPIGRules>) => IAPIGLocal;
    executeHook: ({ prefix, command }: {
        prefix: 'pre' | 'post';
        command: string;
    }) => Promise<void>;
    pack: () => Promise<ReadStream>;
};
