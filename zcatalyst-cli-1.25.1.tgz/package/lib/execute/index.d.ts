import { IFnTarget } from '../fn-utils/lib/common.js';
declare const _default: (target: IFnTarget, input: Record<string, unknown>) => Promise<void>;
export default _default;
