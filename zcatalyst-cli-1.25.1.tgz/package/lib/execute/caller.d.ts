/// <reference types="node" />
import { IFnTarget } from '../fn-utils/lib/common';
import { EventEmitter } from 'stream';
import { IServerDetails } from '../serve/server';
import { FnExecutionHandler } from '../shell/dependencies/non-http-function/fn-execution-handler';
export declare class Caller extends FnExecutionHandler {
    responseFile: string;
    metaFile: string;
    slaveFnTarget: Record<string, string>;
    isContainer: boolean;
    constructor(serverDetails: IServerDetails<IFnTarget>, localFnEvents: EventEmitter);
    call(data: Record<string, unknown>): Promise<void>;
    kill(): Promise<void>;
}
