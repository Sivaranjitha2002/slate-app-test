import { LoDashStatic } from 'lodash';
export interface ILodashMixin extends LoDashStatic {
    sleep: (ms: number) => Promise<void>;
    randomString: (length: number) => string;
    randomNumber: (length: number) => string;
    removeNullAndUndefined: (obj: unknown) => unknown;
    parseJSON: (str: string) => JSON | undefined;
    camelToTitleCase: (str: string) => string;
}
export declare const JS: ILodashMixin;
