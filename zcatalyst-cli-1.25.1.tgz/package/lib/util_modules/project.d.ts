interface ISimpleObject {
    [key: string]: unknown;
}
export interface IDomainServerObj {
    project_domain_id: string;
    project_domain_name: string;
    user_auth?: unknown;
    mobile_auth?: unknown;
}
export interface IDomainCliObj {
    id: string;
    name: string;
}
export interface IEnvironmentServerObj extends ISimpleObject {
    env_name: string;
    env_type: number;
    project_details: IProjectServerObj;
    is_default: boolean;
    env_zgid: string;
}
export interface IEnvironmentCliObj extends ISimpleObject {
    name: string;
    id: string;
    type: number;
}
export interface IProjectServerObj extends ISimpleObject {
    id: string;
    project_name: string;
    platforms?: Array<unknown>;
    project_domain_details: IDomainServerObj;
    db_type?: string;
    redirect_url?: string;
    created_time?: string;
    created_by?: unknown;
    project_type?: string;
    timezone: string;
}
export interface IProjectCliObj extends ISimpleObject {
    id: string;
    name: string;
    domain: IDomainCliObj;
    timezone: string;
    type?: string;
}
export declare function getProjectId(): string;
export declare function getProjectId<T>(fallback?: T): T | string;
export declare function getProjectName<T>(fallback?: T): T | string;
export declare function getEnvId(fallback?: string): string | undefined;
export declare function getEnvName(fallback?: string): string;
export declare function getDomainPrefix<T>(fallback?: T): T | string;
export declare function getDomainKey<T>(fallback?: T): T | string;
export declare function getProjectTimezone<T>(fallback: T): T | string;
export declare function getDefaultProjectId<T>(fallback?: T): T | string;
export declare function getDefaultProjectName<T>(fallback?: T): T | string;
export declare function getDefaultEnvName<T>(fallback?: T): T | string;
export declare function getProjectRoot(fallback?: string): string;
export declare function makeDefaultProjectActive(): Promise<void>;
export declare function transformProject(projectObj: IProjectServerObj | IProjectCliObj): IProjectCliObj;
export declare function transformEnv(envObj: IEnvironmentServerObj | IEnvironmentCliObj): IEnvironmentCliObj;
export declare function removeProject(projectId: string): Promise<void>;
export declare function upsertEnv(projectId: string, envObj: IEnvironmentCliObj | IEnvironmentServerObj, { base, active }: {
    base?: boolean;
    active?: boolean;
}): Promise<void>;
export declare function upsertProject(projectObj: IProjectCliObj | IProjectServerObj, { base, active }: {
    base?: boolean;
    active?: boolean;
}): Promise<void>;
export declare function resolveProjectPath(...filePath: Array<string>): string;
export {};
