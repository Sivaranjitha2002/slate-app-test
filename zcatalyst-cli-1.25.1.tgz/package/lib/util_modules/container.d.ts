export declare function showContainerUsagePrompt(): Promise<void>;
export declare function isSocketAccessible(throwErr?: boolean): Promise<boolean>;
export declare function isContainer(): boolean;
