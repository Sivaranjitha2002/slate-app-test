export interface ICliStore {
    [key: string]: unknown;
}
declare class runtime {
    readonly storeName: string;
    store: ICliStore;
    constructor(storeName: string);
    get<T, U = T>(path: string, fallback?: U): T | U;
    set(path: string, value: unknown): void;
}
export default runtime;
