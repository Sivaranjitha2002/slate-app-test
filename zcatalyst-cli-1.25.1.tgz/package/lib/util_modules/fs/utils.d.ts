export declare const untildify: (pth: string) => string;
