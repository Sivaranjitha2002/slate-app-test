/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import fs, { CopyFilterAsync, Stats } from 'fs-extra';
type OutputType = 'buffer' | 'utf8' | undefined;
type OutputByType<T> = T extends 'buffer' ? Buffer : string;
export declare function isPathExists(path: string): Promise<boolean>;
export declare function dirExists(pth: string): Promise<boolean>;
export declare function fileExists(pth: string): Promise<boolean>;
export declare function getFileDetails(pth: string): Promise<Stats>;
export declare function readFile(pth: string): Promise<string | undefined>;
export declare function readFile<T extends OutputType>(pth: string, type?: T): Promise<OutputByType<T> | undefined>;
export declare function tempFile(): Promise<string>;
export declare function tempFile(name: string): Promise<string>;
export declare function tempFile(name: string, content: string | Buffer): Promise<string>;
export declare function writeFile(pth: string, content: Buffer | Uint8Array | string, encoding?: string): Promise<void>;
export declare function dirList(dir: string): Promise<Array<string>>;
export declare function walk(dir: string, { filter, depth, includeDirPaths }?: {
    filter?: {
        exclude: Array<string> | ((path: string) => Promise<boolean>);
        excludeDir: boolean;
        ignoreFiles?: boolean;
    };
    depth?: number;
    includeDirPaths?: boolean;
}): Promise<Array<{
    path: string;
    stats: fs.Stats;
}>>;
export declare function ensureFile(filePath: string, cleanFile?: boolean): Promise<void>;
export declare function ensureDir(pth: string): Promise<void>;
export declare function deleteFile(filePath: string): Promise<void>;
export declare function deleteDir(dir: string): Promise<void>;
export declare function copyFile(src: string, dest: string, overwrite?: boolean): Promise<void>;
export declare function copyFiles(src: Array<string>, dest: string): Promise<Array<void>>;
export declare function copyDir(srcDir: string, destDir: string, { filter }?: {
    filter?: CopyFilterAsync;
}): Promise<void>;
export declare function rename(pth: string, modifier?: (baseName: string, extention: string) => string): Promise<void>;
export declare const findAndReplace: (pth: string) => (templates: string | Array<string>, finalWords: string | Array<string>) => Promise<void>;
export declare function emptyDir(dir: string): Promise<void>;
export declare function readJSONFile<T = Record<string, any>>(pth: string, opts?: fs.ReadOptions & {
    checkpath?: boolean;
}): Promise<T | undefined>;
export declare function writeJSONFile(pth: string, object: Record<string, unknown>, opts?: fs.WriteOptions): Promise<void>;
export declare function chmod(path: string, mode: string, { checkPath, recursive }?: {
    checkPath?: boolean | undefined;
    recursive?: boolean | undefined;
}): Promise<void>;
export declare function readStreamAsJSON<T = Record<string, unknown>>(stream: NodeJS.ReadableStream): Promise<T>;
export declare function isDirEmpty(pth: string): Promise<boolean>;
export {};
