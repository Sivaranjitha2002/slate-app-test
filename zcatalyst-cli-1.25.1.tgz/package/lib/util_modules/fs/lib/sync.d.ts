/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import fs, { CopyFilterSync } from 'fs-extra';
export declare function getWriteStream(pth: string, mode?: number): fs.WriteStream;
export declare function getReadStream(pth: string): fs.ReadStream;
export declare function readSymLink(pth: string): string;
export declare function fileExists(pth: string): boolean;
export declare function pathExists(pth: string): boolean;
export declare function dirExists(pth: string): boolean;
export declare function getAllDirs(srcPath: string): Array<string>;
export declare function getAllFiles(srcPath: string): Array<string>;
export declare function deleteFile(pth: string): void;
export declare function readFile(pth: string, encoding?: BufferEncoding): string | undefined;
export declare function ensureDir(dir: string): void;
export declare function ensureFile(filePath: string, cleanFile?: boolean): void;
export declare function writeFile(pth: string, data: Buffer | Uint8Array | string, encoding?: BufferEncoding): void;
export declare function appendFile(pth: string, data: Buffer | Uint8Array | string, encoding?: BufferEncoding): void;
export declare function modifyFileName(pth: string | Array<string>, modifier: (fullPth: string, extension: string) => string): Array<string>;
export declare function renameFile(pth: string | Array<string>, modifier: (fullPth: string, extension: string) => string): Array<void>;
export declare function isPathOutside(from: string, to: string): boolean;
export declare function isPathInside(from: string, to: string): boolean;
export declare function deleteDir(dir: string): void;
export declare function tempFile(name?: string): string;
export declare function deleteTempDir(): void;
export declare function copyFile(src: string, dest: string): void;
export declare function copyFiles(src: Array<string>, dest: string): void;
export declare function copyDir(srcDir: string, destDir: string, { filter, overwrite, errorOnExist }?: {
    filter?: CopyFilterSync;
    overwrite?: boolean;
    errorOnExist?: boolean;
}): void;
export declare function emptyDir(dir: string): void;
export declare function readJSONFile(pth: string, opts?: fs.ReadOptions & {
    checkpath?: boolean;
}): Record<string, any> | undefined;
export declare function writeJSONFile(pth: string, object: Record<string, unknown>, opts?: fs.WriteOptions): void;
export declare function readPackageJson(): Record<string, unknown> | undefined;
export declare function isDirEmpty(pth: string): boolean;
