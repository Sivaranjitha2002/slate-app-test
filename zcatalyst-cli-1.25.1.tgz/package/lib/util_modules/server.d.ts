/// <reference types="node" />
/// <reference types="node" />
import type { ClientRequest, Server } from 'http';
import ProxyServer from 'http-proxy';
import { Socket } from 'net';
export declare class ConnectionDestroyer {
    private readonly server;
    connections: Set<Socket | ClientRequest>;
    constructor(server: Server | ProxyServer);
    destroy(terminate?: boolean, err?: Error): Promise<void>;
}
export declare function getHostIP(throwErr?: boolean): Promise<string | undefined>;
export declare function isPortListening(port: string | number, retry?: number, retryInterval?: number): Promise<void>;
