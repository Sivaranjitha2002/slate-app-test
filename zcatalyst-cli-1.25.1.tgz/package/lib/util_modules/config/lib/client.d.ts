export interface IClientConfig {
    source?: string;
    ignore?: Array<string>;
    scripts?: {
        [x: string]: string;
    };
    plugin?: {
        [x: string]: string;
    } | string;
}
export declare function raw(throwError?: boolean): IClientConfig | undefined;
export declare function source(fallback?: "client"): string;
export declare function plugin(): {
    [x: string]: string;
} | undefined;
export declare function plugin(name: string): string | undefined;
export declare function ignore(sourcePath: string): Array<string>;
export declare function script<T>(name?: string, fallback?: T): T | {
    [x: string]: string;
} | string;
