import { IProjectServerObj } from '../../project';
export type FrameworkType = {
    label: string;
    name: string;
    keywords: Array<string>;
    settings: {
        dev_command: CommandType;
        install_command: CommandType;
        build_command: CommandType;
        output_dir: CommandType;
        deployment_name: string;
    };
};
export type CommandType = {
    placeholder: string;
    value: string;
};
export interface SlateBuildInfo {
    id: string;
    status: string;
    created_time: string;
    created_by: {
        zuid: string;
        is_confirmed: boolean;
        email_id: string;
        first_name: string;
        last_name: string;
        user_type: string;
        user_id: string;
    };
    duration?: string;
    deployment_id: string;
    build_meta: Record<string, unknown>;
}
export interface IAppUpdatedByDetails {
    zuid: string;
    is_confirmed: boolean;
    email_id: string;
    first_name: string;
    last_name: string;
    user_type: string;
    user_id: string;
}
export interface ISlateUploadResponse {
    id: string;
    name: string;
    created_time: string;
    modified_time: string;
    created_by: IAppUpdatedByDetails;
    modified_by: IAppUpdatedByDetails;
    app_config: ISlateConfigDetails;
    app_type: string;
    project_details: IProjectServerObj;
    deployment_type_config: {
        id: string;
        app_id: string;
        name: string;
        auto_deploy: false;
        created_time: string;
        modified_time: string;
        created_by: IAppUpdatedByDetails;
        modified_by: IAppUpdatedByDetails;
        status: string;
        type: string;
        current_build: SlateBuildInfo;
        upcoming_build: SlateBuildInfo;
        rollback_build: SlateBuildInfo;
        origin_domain: string;
        domain: string;
    };
}
export interface ISlateAppInfo {
    id: string;
    name: string;
    created_time: string;
    modified_time: string;
    created_by: IAppUpdatedByDetails;
    modified_by: IAppUpdatedByDetails;
    app_config: ISlateConfigDetails;
    app_type: string;
    project_details: IProjectServerObj;
}
export interface ISlateConfigDetails {
    install_command?: string;
    run_command?: string;
    build_command?: string;
    deployment_name?: string;
    framework?: string;
    build_path?: string;
    root_path?: string;
    node_runtime?: string;
    env_variables?: Array<string>;
}
export interface ISlateConfig {
    config?: ISlateConfigDetails;
    details?: ISlateUploadResponse;
    source: string;
    name: string;
    validity: {
        valid?: boolean;
        reason?: string;
    };
}
export declare function raw(throwError?: boolean): Array<ISlateConfig> | undefined;
export declare function getTargetDetails(targ: ISlateConfig): Promise<ISlateConfig>;
export declare function getAllTargetDetails(throwErr?: boolean): Promise<Array<ISlateConfig> | undefined>;
