export interface IAPIGConfig {
    rules?: string;
    enabled?: boolean;
    scripts?: {
        [x: string]: string;
    };
}
export declare function raw(throwError?: boolean): IAPIGConfig | undefined;
export declare function rules(): string;
export declare function enabled(): boolean;
export declare function enabled<T>(fallback?: T): boolean | T;
export declare function script<T>(name?: string, fallback?: T): T | {
    [x: string]: string;
} | string;
export declare const source: typeof rules;
