export interface IAppSailConfig {
    source: string;
    name: string;
    command?: string;
    memory?: number;
    port?: {
        http: number;
        debug: number;
    };
}
export interface IAppSailServerConfig extends Record<string, unknown> {
    command?: string;
    build_path?: string;
    buildPath?: string;
    ignore?: Array<string>;
    scripts?: Record<'predeploy' | 'postdeploy' | 'preserve' | 'postserve', string>;
    stack?: string;
    env_variables?: Record<string, string>;
    platform?: 'javase' | 'war';
    memory?: number;
    catalyst_auth?: boolean;
    login_redirect?: string;
    port?: {
        http?: number;
        debug?: number;
    };
    raw: {
        source_path?: string;
        build_path?: string;
    };
}
export type TAppSailDetails = {
    name: string;
    source: string;
    validity: {
        valid: boolean;
        reason?: string;
    };
    runtime?: 'custom' | 'catalyst';
    url?: string;
    config?: IAppSailServerConfig;
};
export declare const CONTAINER_IMAGE_PROTOCOLS: {
    docker: string;
    dockerArchive: string;
};
export declare function raw(throwError?: boolean): Array<TAppSailDetails> | undefined;
export declare function getTargetDetails(name: string): Promise<TAppSailDetails | undefined>;
export declare function getAllTargetDetails(throwErr?: boolean): Promise<Array<TAppSailDetails> | undefined>;
export declare function unlinkAppSail(name: string): Promise<boolean>;
