export interface IFunctionsConfig {
    source: string;
    ignore?: Array<string>;
    scripts?: {
        [x: string]: string;
    };
    targets?: Array<string | Omit<IFunctionsConfig, 'targets'>>;
    plugin?: {
        [x: string]: string;
    } | string;
}
export declare function source(fallback?: "functions"): string;
export declare function ignore(sourcePath?: string): Array<string>;
export declare function targets<T>(fallback?: T): T | Array<string>;
export declare function script<T>(name?: string, fallback?: T): T | {
    [x: string]: string;
} | string;
export declare function script<T>(name?: string, fallback?: T, sourcePath?: string): T | {
    [x: string]: string;
} | string;
export declare function plugin(): {
    [x: string]: string;
} | undefined;
export declare function plugin(name: string, sourcePath?: string): string | undefined;
export declare function plugin(name?: string, sourcePath?: string): {
    [x: string]: string;
} | string | undefined;
export interface ICatalystFunctionsDeploymentConfig {
    name: string;
    stack: string;
    type: string;
    env_variables: string | Record<string, string>;
}
export interface ICatalystFunctionsExecutionConfig {
    main: string;
}
export interface ICatalystFunctionsScriptsConfig {
    preserve: string;
    postserve: string;
    predeploy: string;
    postdeploy: string;
}
export interface ICatalystFunctionConfig {
    source: string;
    deployment: ICatalystFunctionsDeploymentConfig;
    execution: ICatalystFunctionsDeploymentConfig;
    scripts: ICatalystFunctionsScriptsConfig;
}
