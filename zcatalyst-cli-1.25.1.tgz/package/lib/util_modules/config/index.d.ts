import * as apigConfig from './lib/apig';
import * as clientConfig from './lib/client';
import * as functionsConfig from './lib/functions';
import * as appSailConfig from './lib/appsail';
import * as slateConfig from './lib/slate.js';
export { clientConfig, functionsConfig, apigConfig, appSailConfig, slateConfig };
