import { transports as winstonTransports } from 'winston';
export declare const transport: {
    console: winstonTransports.ConsoleTransportInstance;
    log_file: winstonTransports.FileTransportInstance;
    http_log: winstonTransports.FileTransportInstance;
};
export declare function verbose(enable?: boolean): void;
export declare const logger: import("winston").Logger;
export default logger;
