export declare function log(level: 'info' | 'warn' | 'error', message: string, ignoreHttpLogger?: boolean): void;
export declare function info(msg?: unknown, ...params: Array<unknown>): void;
export declare function debug(msg?: unknown, ...params: Array<unknown>): void;
export declare function success(msg: string, level?: string, label?: string, padLeft?: string): void;
export declare function message(msg: string, level?: string, label?: string, padLeft?: string): void;
export declare function warning(msg: string, level?: string, label?: string, padLeft?: string): void;
export declare function error(msg: string, level?: string, label?: string, padLeft?: string): void;
export declare const local: {
    info: (msg?: string) => void;
    warn: (msg?: string) => void;
    error: (msg?: string) => void;
};
export declare function labeled(label: string, line: string, padLeft?: string): {
    SUCCESS: () => void;
    WARN: () => void;
    MESSAGE: () => void;
    ERROR: () => void;
};
export * from './utils';
