/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { Direction } from 'readline';
import { PassThrough } from 'stream';
export declare const CHAR: {
    success: string;
    warning: string;
    info: string;
    error: string;
};
export declare class TTYPassThrough extends PassThrough {
    columns: number;
    rows: number;
    isTTY: boolean;
    _write(chunk: Buffer, encoding: BufferEncoding, callback: (error?: Error | null) => void): void;
    clearLine(dir: Direction, callback?: () => void): boolean;
    clearScreenDown(callback?: () => void): boolean;
    cursorTo(x: number, y: number, callback?: () => void): boolean;
    moveCursor(dx: number, dy: number, callback?: () => void): boolean;
    getColorDepth(env?: object): number;
    hasColors(count: number, env?: object): boolean;
    getWindowSize(): [number, number];
}
export declare class LogStreamFactory {
    #private;
    static getStream(): TTYPassThrough;
}
