export declare function getActiveDC(dcOption?: string): string;
export declare function getActiveDCType(): {
    loc: string;
    value: string;
    w_auth: string;
    m_auth: string;
    ext: string;
    ref: string;
} | undefined;
export declare function updateActiveDC(dc: string): void;
