export declare const isCI: boolean;
export declare const isMac: boolean;
export declare const isWindows: boolean;
export declare const isVsCode: boolean;
export declare function isPrimaryShell(): boolean;
export declare function envOverride(envname: string, value: string): string;
export declare function getEnvVariable(variable: string, fallback?: unknown): unknown;
