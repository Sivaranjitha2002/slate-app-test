declare const _default: Readonly<{
    Datastore: string[];
    Cache: string[];
    UserManagement: string[];
    Filestore: string[];
    Stratus: string[];
    Webapp: string[];
    Github: string[];
    Custom: string[];
}>;
export default _default;
