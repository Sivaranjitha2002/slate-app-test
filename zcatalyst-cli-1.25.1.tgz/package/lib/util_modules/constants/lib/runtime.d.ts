declare const RUNTIME: Readonly<{
    language: {
        node: {
            value: string;
            label: string;
        };
        java: {
            value: string;
            label: string;
        };
        python: {
            value: string;
            label: string;
        };
    };
    memory: number[];
}>;
export default RUNTIME;
