declare const _default: Readonly<{
    us: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    eu: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    in: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    au: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    ca: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    sa: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    jp: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
    uae: {
        loc: string;
        ref: string;
        value: string;
        w_auth: string;
        m_auth: string;
        ext: string;
    };
}>;
export default _default;
