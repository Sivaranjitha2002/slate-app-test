declare const _default: Readonly<{
    functions: {
        type: {
            basicio: "bio";
            event: "event";
            cron: "cron";
            applogic: "applogic";
            advancedio: "aio";
            integration: "integ";
            browser_logic: "browserlogic";
            job: "job";
        };
    };
}>;
export default _default;
