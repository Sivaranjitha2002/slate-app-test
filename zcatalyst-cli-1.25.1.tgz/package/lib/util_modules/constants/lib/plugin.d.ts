declare const _default: Readonly<{
    mangaer: {
        npm: {
            command: string;
            opts: string[];
        };
        yarn: {
            command: string;
            opts: string[];
        };
    };
    client: string[];
    react: {
        plugin: string;
        runner_command: string[];
    };
    lyte: {
        plugin: string;
    };
    angular: {
        plugin: string;
        runner_command: string[];
        collection_name: string;
        runner_package: string;
    };
}>;
export default _default;
