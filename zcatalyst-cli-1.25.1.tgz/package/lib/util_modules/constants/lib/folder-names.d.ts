declare const _default: Readonly<{
    client: "client";
    functions: "functions";
    slate: ".slate";
    java_fn_lib: "lib";
    build: ".build";
    output: ".output";
}>;
export default _default;
