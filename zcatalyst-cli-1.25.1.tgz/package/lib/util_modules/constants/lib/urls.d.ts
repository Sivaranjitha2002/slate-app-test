export default class URL {
    private static readonly _authBase;
    private static readonly _portalBase;
    private static readonly _adminBase;
    private static readonly _appBase;
    private static readonly _appSailDomainBase;
    private static readonly _zohoStaticBase;
    private static readonly _consoleBase;
    private static readonly _stratusSuffixBase;
    private static readonly _zohoCDNBase;
    private static readonly _contacts;
    static get zohoCDNUS(): string;
    static get zohoCDN(): string;
    static get auth(): string;
    static get iamPortal(): string;
    static get admin(): string;
    static get app(): string;
    static get appSailDomain(): string;
    static get catalystStatic(): string;
    static get console(): string;
    static get contacts(): string;
    static get stratusSuffix(): string;
    static external: Readonly<{
        gitHubAPI: "https://api.github.com";
        gitHubWeb: "https://github.com";
    }>;
}
