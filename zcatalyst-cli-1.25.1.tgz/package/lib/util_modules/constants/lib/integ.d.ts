declare const _default: Readonly<{
    services: {
        cliq: string;
        convokraft: string;
    };
    service_map: {
        [x: string]: string;
    };
    java_dependencies: {
        [x: string]: string;
    };
}>;
export default _default;
