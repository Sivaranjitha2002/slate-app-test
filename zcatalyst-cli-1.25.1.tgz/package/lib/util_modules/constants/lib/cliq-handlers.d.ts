declare const _default: Readonly<{
    event_template_dir: string;
    node_handlers_template_dir: "./handlers";
    java_handlers_template_dir: "./com/handlers";
    python_handlers_template_dir: "./handlers";
    node_handlers_path: "handlers/";
    java_handlers_path: "com.handlers.";
    python_handlers_path: "handlers/";
    node_template_contents_initial_copy: string[];
    java_template_contents_initial_copy: string[];
    python_template_contents_initial_copy: string[];
    component_handlers: string[];
    node_handler_file_mapping: {
        [x: string]: string;
    };
    java_handler_file_mapping: {
        [x: string]: string;
    };
    python_handler_file_mapping: {
        [x: string]: string;
    };
    handlers_event_template: {
        bot: string[];
        command: string[];
        messageaction: string[];
        widget: string[];
        function: string[];
        extension: string[];
        link_preview: string[];
    };
}>;
export default _default;
