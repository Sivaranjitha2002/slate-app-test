import envPaths from 'env-paths';
declare const _default: Readonly<{
    runtimes: envPaths.Paths;
    userConfig: envPaths.Paths;
}>;
export default _default;
