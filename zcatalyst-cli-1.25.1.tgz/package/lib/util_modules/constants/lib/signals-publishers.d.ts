declare const _default: Readonly<{
    authentication: "authentication";
    datastore: "datastore";
    filestore: "filestore";
    cache: "cache";
    stratus: "stratus";
    custom: "custom";
}>;
export default _default;
