declare const _default: Readonly<{
    log: "catalyst-debug.log";
    http_log: "catalyst-http-log.json";
    rc: ".catalystrc";
    config: "catalyst.json";
    slate: {
        config_json: string;
        static_zip: string;
    };
    client: {
        package_json: string;
        notFoundPage: string;
    };
    functions: {
        python_main: string;
        python_requirements: string;
        node_main: string;
        node_package: string;
        java_main: string;
        java_project: string;
        java_classpath: string;
    };
    apig: {
        user_rules: string;
        system_rules: string;
    };
    catalyst_config: "catalyst-config.json";
    slate_config: "slate-config.toml";
    command_log: ".command.log";
    node_modules: "node_modules";
    catalyst_inputs: "catalyst-inputs.json";
    app_config: "app-config.json";
    package_json: "package.json";
    catalyst_ignore: ".catalystignore";
    cli_config: "cli-config.json";
}>;
export default _default;
