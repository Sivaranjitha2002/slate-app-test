declare const _default: Readonly<{
    template_format: {
        json: string;
        yml: string;
    };
}>;
export default _default;
