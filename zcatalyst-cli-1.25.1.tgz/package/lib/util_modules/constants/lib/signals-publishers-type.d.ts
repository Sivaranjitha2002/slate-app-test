declare const _default: Readonly<{
    zoho: string[];
    cloudscale: string[];
    saas: string[];
    custom: string[];
}>;
export default _default;
