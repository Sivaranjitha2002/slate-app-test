declare const _default: Readonly<{
    datastore: string[];
    cache: string[];
    authentication: string[];
    filestore: string[];
    stratus: string[];
    custom: string[];
}>;
export default _default;
