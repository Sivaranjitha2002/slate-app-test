declare const _default: Readonly<{
    datastore: "Datastore";
    cache: "Cache";
    user: "UserManagement";
    custom: "Custom";
    filestore: "Filestore";
    stratus: "Stratus";
    webapp: "Webapp";
    github: "Github";
}>;
export default _default;
