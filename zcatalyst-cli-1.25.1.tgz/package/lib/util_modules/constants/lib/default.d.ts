declare const _default: Readonly<{
    dc: string;
    env_name: "Development";
    catalystError: "CatalystError";
    scripts: string[];
    serve_port: {
        http: {
            master: number;
            advancedio: number;
            basicio: number;
            browser_logic: number;
            appsail: {
                master: number;
                service: number;
            };
            event: number;
            cron: number;
            job: number;
            integ: number;
            slate: {
                master: number;
                service: number;
            };
            client: number;
        };
        debug: {
            master: number;
            advancedio: number;
            basicio: number;
            browser_logic: number;
            appsail: number;
            client: number;
        };
        search_span: {
            http_port: number;
        };
    };
    event_bus: {
        name: string;
    };
    datastore: {
        column_details: {
            column_name: string;
            data_type: string;
        }[];
    };
}>;
export default _default;
