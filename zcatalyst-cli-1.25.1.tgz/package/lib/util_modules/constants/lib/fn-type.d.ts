declare const _default: Readonly<{
    basic: "bio";
    event: "event";
    cron: "cron";
    applogic: "applogic";
    advanced: "aio";
    integration: "integ";
    browserLogic: "browserlogic";
    job: "job";
}>;
export default _default;
