import { IAPIGRules } from '../../../apig-utils';
declare const _default: IAPIGRules[];
export default _default;
