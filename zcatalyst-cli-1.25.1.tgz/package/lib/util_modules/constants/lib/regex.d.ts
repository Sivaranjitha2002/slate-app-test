declare const _default: Readonly<{
    project: {
        name: RegExp;
        template: RegExp;
    };
    client: {
        package_name: RegExp;
    };
    functions: {
        package: {
            name: RegExp;
            version: RegExp;
        };
    };
    appsail: {
        name: RegExp;
    };
    folder_name: RegExp;
}>;
export default _default;
