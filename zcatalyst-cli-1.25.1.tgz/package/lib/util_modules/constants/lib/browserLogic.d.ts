declare const _default: Readonly<{
    nodejs: {
        Puppeteer: {
            'puppeteer-core': string;
            'zcatalyst-sdk-node': string;
        };
        Playwright: {
            'playwright-core': string;
            'zcatalyst-sdk-node': string;
        };
        Selenium: {
            'selenium-webdriver': string;
            'zcatalyst-sdk-node': string;
        };
    };
    java: {
        Selenium: string[];
    };
}>;
export default _default;
