declare const _default: Readonly<{
    functions: {
        type: {
            bio: string;
            event: string;
            cron: string;
            applogic: string;
            aio: string;
            integ: string;
            browserlogic: string;
            job: string;
        };
    };
}>;
export default _default;
