declare const _default: Readonly<{
    banner: string;
    login_success: string;
    login_fail: string;
    client: {
        basic: {
            new: string;
            socket: string;
        };
        lyte: string;
        react: {
            js: string;
            ts: string;
        };
    };
    applogic: {
        node: string;
    };
    functions: {
        node: {
            bio: string;
            event: string;
            cron: string;
            aio: string;
            integ: {
                [x: string]: string;
            };
            browserlogic: {
                Playwright: string;
                Puppeteer: string;
                Selenium: string;
            };
            job: string;
        };
        java: {
            bio: string;
            event: string;
            cron: string;
            aio: string;
            integ: {
                [x: string]: string;
            };
            browserlogic: {
                Selenium: string;
                Playwright: string;
            };
            job: string;
        };
        python: {
            bio: string;
            event: string;
            cron: string;
            aio: string;
            integ: {
                [x: string]: string;
            };
            job: string;
        };
    };
    event_data: string;
    signal_event_data: string;
    job_data: string;
    init_js: string;
}>;
export default _default;
