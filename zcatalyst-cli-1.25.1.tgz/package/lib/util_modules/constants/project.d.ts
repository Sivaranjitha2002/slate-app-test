declare const PROJECT: Readonly<{
    accepted_types: string[];
}>;
export default PROJECT;
