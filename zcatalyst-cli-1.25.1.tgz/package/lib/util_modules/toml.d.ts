export declare function parseTOML(str: string): unknown;
export declare function convertTOML(object: Record<string, unknown>): string;
