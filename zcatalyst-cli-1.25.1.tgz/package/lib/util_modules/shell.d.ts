/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { ChildProcess, SpawnOptions, SpawnSyncReturns } from 'child_process';
export type asyncSpawnResposne = {
    message: string;
    stdout: string;
    stderr: string;
    status: number;
};
export declare function clearStdout(fullClear?: boolean): void;
export declare function clearLine(stream?: typeof process.stderr | typeof process.stdout): void;
export declare function supportsUnicode(): boolean;
export declare function spawn(command: string, opts?: Array<string>, { cwd, stdio, shell, ...otherOpts }?: SpawnOptions): {
    SYNC: () => SpawnSyncReturns<string | Buffer>;
    ASYNC: () => Promise<asyncSpawnResposne>;
    RAW: () => ChildProcess;
};
export declare function which(commandName: string, { alwaysResolve }: {
    alwaysResolve: boolean;
}): Promise<boolean>;
