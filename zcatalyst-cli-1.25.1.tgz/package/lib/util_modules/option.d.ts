export declare function getCurrentCommand<T>(fallback?: T): T | string;
export declare function getOptionValue<T = string | boolean>(key: string, fallback?: T): T;
export declare function setGlobalOption(key: string, value: unknown): void;
export declare function getGlobalOptionValue<T>(key: string, fallback?: T): T | string;
export declare function getUnknownOpts<T>(fallback?: T): T | Array<string>;
