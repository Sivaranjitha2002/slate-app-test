declare const _default: (event: string, message: string, duration: number) => Promise<void>;
export default _default;
