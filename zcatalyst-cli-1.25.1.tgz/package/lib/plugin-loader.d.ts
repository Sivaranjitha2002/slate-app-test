/// <reference types="node" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import type { Stream } from 'stream';
export type IPlugin = (...args: Array<unknown>) => Promise<ChildProcess | EventListener | boolean | string | Stream>;
export default function pluginLoader(feature: 'client' | 'functions', name: string, source?: string): Promise<IPlugin | undefined>;
