export declare const CONFIG_KEYS: {
    python39_bin: string;
    java8_bin: string;
    java11_bin: string;
    java17_bin: string;
    javac_disableWarnings: string;
    serve_container: string;
};
declare class UserConfig {
    private configFilePath;
    private config;
    private validKeys;
    constructor();
    set(key: string, value: string): Record<string, string>;
    get(key: string): string;
    delete(key: string): boolean;
    list(): string;
    has(key: string): boolean;
    refresh(): void;
}
declare const _default: UserConfig;
export default _default;
