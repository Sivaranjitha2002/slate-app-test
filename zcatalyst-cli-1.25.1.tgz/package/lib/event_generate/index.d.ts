import { EVENT_SOURCE } from '../util_modules/constants';
export declare function generate(source: keyof typeof EVENT_SOURCE, action: string): Promise<Record<string, unknown>>;
