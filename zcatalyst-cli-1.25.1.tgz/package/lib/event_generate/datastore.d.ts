export interface IDatastoreColumnDetails {
    column_name: string;
    data_type: string;
    table_id?: string;
}
export declare let sourceId: string;
export declare function getData(options?: Record<string, string | undefined>): Promise<Record<string, unknown>>;
