export declare let sourceId: string;
export declare function getData(options?: Record<string, string | undefined>): Promise<Record<string, unknown>>;
