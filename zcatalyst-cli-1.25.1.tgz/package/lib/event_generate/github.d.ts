export declare const sourceId = "NULL";
export declare function getData(): Promise<Record<string, unknown>>;
