export declare function getRuleId(): Promise<string>;
