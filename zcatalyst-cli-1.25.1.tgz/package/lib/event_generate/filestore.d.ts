export declare let sourceId: string;
export declare function getData(options?: Record<string, unknown>): Promise<Record<string, unknown>>;
