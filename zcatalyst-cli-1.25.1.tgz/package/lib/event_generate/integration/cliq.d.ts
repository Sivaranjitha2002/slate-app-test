declare const _default: (inputs: string) => Promise<string | undefined>;
export default _default;
