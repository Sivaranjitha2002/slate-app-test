import { TAppSailDetails } from './util_modules/config/lib/appsail';
export declare function filterTargets(allTargets: Array<TAppSailDetails>): Array<TAppSailDetails>;
export declare function validateAppSail(targDetails: Array<TAppSailDetails>): Promise<Array<TAppSailDetails>>;
