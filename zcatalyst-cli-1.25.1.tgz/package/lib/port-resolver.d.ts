declare const featureRef: {
    client: string;
    aio: string;
    bio: string;
    master: string;
    appsail: string;
    slate: string;
    browserlogic: string;
};
type TFeatureType = 'http' | 'debug';
type TGetPortOptions = {
    name?: string;
    duplicateCheck?: boolean;
    searchSpan?: number;
    fallbackNeeded?: boolean;
    server?: 'master' | 'service';
};
export default class PortResolver {
    #private;
    static freePort(port: number): void;
    static getFreePort(startPort: number, searchSpan?: number, dupCheck?: boolean): Promise<number>;
    static getPort(feature: keyof typeof featureRef, type: TFeatureType, { name, duplicateCheck, searchSpan, fallbackNeeded, server }?: TGetPortOptions): Promise<number>;
}
export {};
