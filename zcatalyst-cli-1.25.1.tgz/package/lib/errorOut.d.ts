import CatalystError from './error/index.js';
declare const _default: (error?: Error | string | CatalystError, status?: number) => void;
export default _default;
