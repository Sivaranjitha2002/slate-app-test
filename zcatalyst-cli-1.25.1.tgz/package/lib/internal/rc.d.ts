import { IEnvironmentCliObj, IProjectCliObj } from '../util_modules/project';
interface IRCData {
    [x: string]: unknown;
}
declare class RC {
    path: string;
    data: IRCData;
    private isLoaded;
    constructor(rcpath: string, data?: IRCData);
    set(key: string | Array<string>, value: unknown): void;
    get<T>(key: string | Array<string>, fallback?: T): T;
    getProjectById(projectId: string): IProjectCliObj | undefined;
    getProjectByName(projectName: string): IProjectCliObj | undefined;
    associateEnv(projectId: string, env: IEnvironmentCliObj, { base, active }: {
        base: boolean;
        active: boolean;
    }): Promise<void>;
    removeEnv(projectId: string, envId: string): Promise<void>;
    upsertProject(project: IProjectCliObj, { base, ignoreEnv, active }?: {
        base?: boolean;
        ignoreEnv?: boolean;
        active?: boolean;
    }): Promise<void>;
    removeProject(id: string): Promise<void>;
    _reIndex(arr: Array<IProjectCliObj | IEnvironmentCliObj>, removedIdx: number, pth: string): void;
    save(): Promise<void>;
    syncSave(): void;
    delete(): Promise<void>;
    get hasProjects(): boolean;
    get projects(): Array<IProjectCliObj>;
    get defaultEnvIdx(): number;
    get defaultProjectIdx(): number;
    get activeEnvIdx(): number;
    get activeProjectIdx(): number;
    get defaultProject(): IProjectCliObj | undefined;
    get activeProject(): IProjectCliObj | undefined;
    get defaultEnv(): IEnvironmentCliObj | undefined;
    get activeEnv(): IEnvironmentCliObj | undefined;
    get loaded(): boolean;
    set loaded(load: boolean);
    static loadFile(rcpath: string): Promise<RC>;
    static load(): Promise<RC>;
}
export default RC;
