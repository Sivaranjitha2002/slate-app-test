interface IConfigData {
    [x: string]: unknown;
}
declare class Config {
    configPath: string;
    data: IConfigData;
    private isLoaded;
    constructor(configPath: string, src?: IConfigData);
    get<T>(key: string, fallback?: T): T;
    set(key: string, value: unknown): IConfigData;
    unset(key: string): boolean;
    has(key: string): boolean;
    save(): Promise<void>;
    syncSave(): void;
    get loaded(): boolean;
    set loaded(load: boolean);
    static load(canIgnore: boolean): Promise<Config>;
}
export default Config;
