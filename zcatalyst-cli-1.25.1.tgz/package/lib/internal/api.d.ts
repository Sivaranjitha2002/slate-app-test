/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import request from 'request';
import Progress, { IProgress } from '../progress';
import { ReadStream } from 'fs';
export interface IAPILogOpts {
    uploadProgress?: IProgress;
    progress?: IProgress;
    skipQuery?: boolean;
    skipReqBody?: boolean;
    skipRespBody?: boolean;
    stream?: ReadStream;
    awaitingSpinner?: string;
}
interface IAPIBaseResponse {
    body: unknown;
    status: number;
    response: request.Response;
}
export interface IAPIJsonResponse extends IAPIBaseResponse {
    body: Record<string, unknown>;
}
export interface IAPIBufferResponse extends IAPIBaseResponse {
    body: Buffer;
}
export interface IAPIStringResponse extends IAPIBaseResponse {
    body: string;
}
export type IAPIResponse = IAPIJsonResponse & IAPIBufferResponse & IAPIStringResponse;
export interface IAPIOptions extends request.CoreOptions {
    origin?: string;
    resolveOnError?: boolean;
    printError?: boolean;
    maxRetry?: number;
    authNeeded?: boolean;
    log?: IAPILogOpts;
    envId?: string;
}
declare class API {
    requestOpts: request.CoreOptions & request.OptionsWithUrl;
    authNeeded: boolean;
    resolveOnHTTPError: boolean;
    printError?: boolean;
    logOpts: IAPILogOpts;
    maxRetryCount: number;
    retryCount: number;
    uploadProgress?: Progress;
    downloadProgress?: Progress;
    showWarning: boolean;
    constructor({ authNeeded, resolveOnError, maxRetry, env, log, headers, isExternal, origin, json, showWarning, envId, printError }?: IAPIOptions & {
        env?: string;
        isExternal?: boolean;
        showWarning?: boolean;
    });
    _logReq(): void;
    _logResp(resp: request.Response): void;
    _logUploadProgress({ chunk, error }?: {
        chunk?: string | Buffer;
        error?: Error;
    }): void;
    _logDownloadProgress({ chunk, error }?: {
        chunk?: string | Buffer;
        error?: Error;
    }): void;
    _addAuthHeader(): Promise<void>;
    _parseResponse(resp: request.Response, body: string | Buffer | undefined, rawResponse: Array<Buffer>): IAPIResponse;
    _retry(err: Error): Promise<IAPIResponse>;
    _request(retry?: boolean): Promise<IAPIResponse>;
    fire(method: 'GET' | 'PUT' | 'POST' | 'DELETE' | 'HEAD' | 'PATCH', path: string, options?: IAPIOptions): Promise<IAPIResponse>;
    get(path: string, options?: Omit<IAPIOptions, 'envId'>): Promise<IAPIResponse>;
    put(path: string, options?: Omit<IAPIOptions, 'envId'>): Promise<IAPIResponse>;
    post(path: string, options?: Omit<IAPIOptions, 'envId'>): Promise<IAPIResponse>;
    delete(path: string, options?: Omit<IAPIOptions, 'envId'>): Promise<IAPIResponse>;
    head(path: string): Promise<IAPIBaseResponse>;
    patch(path: string, options?: Omit<IAPIOptions, 'envId'>): Promise<IAPIResponse>;
}
export default API;
