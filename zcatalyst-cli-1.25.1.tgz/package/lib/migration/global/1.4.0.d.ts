export declare const isRequire: () => boolean;
export declare const migrate: () => void;
