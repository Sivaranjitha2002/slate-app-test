export interface IMigration {
    completed: boolean;
    error?: string;
}
declare const _default: (currentVersion: string) => Promise<Array<void>>;
export default _default;
