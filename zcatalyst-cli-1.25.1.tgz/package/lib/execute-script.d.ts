export declare function executeCommand(exeCommand: string, { moduleSource, feature }: {
    moduleSource: string;
    feature: string;
}): Promise<void>;
declare const _default: (commandName: string) => Promise<void>;
export default _default;
