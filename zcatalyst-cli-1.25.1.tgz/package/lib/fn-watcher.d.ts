import { IFnTarget } from './fn-utils/lib/common';
export type EventType = {
    evnt: string;
    pth: string;
    at: number;
};
declare const _default: (target: IFnTarget) => Promise<void>;
export default _default;
