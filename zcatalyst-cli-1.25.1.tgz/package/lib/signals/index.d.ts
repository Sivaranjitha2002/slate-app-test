import { SIGNALS_API_NAMES } from '../util_modules/constants';
export declare function generate(publisher: keyof typeof SIGNALS_API_NAMES, event: string): Promise<Record<string, unknown>>;
