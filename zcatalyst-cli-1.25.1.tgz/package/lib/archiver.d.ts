/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { ReadStream } from 'fs-extra';
declare class Archiver {
    name: string;
    private jszip;
    private promiseArr;
    content: unknown;
    constructor(name?: string);
    static maxWriteLimit: number;
    load(content: Buffer | string, { createFolders }?: {
        createFolders?: boolean | undefined;
    }): Archiver;
    private _writeFolder;
    private _writeAllFile;
    private getFileMode;
    private _writeFile;
    readFile(relPath: string | RegExp): Promise<string | undefined>;
    extract(to: string, from?: string | RegExp, { isFolder, recursive, ignoreLevel }?: {
        isFolder?: boolean | undefined;
        recursive?: boolean | undefined;
        ignoreLevel?: number | undefined;
    }): Archiver;
    getUnixPath(pth: string): string;
    add(pth: string, content: string | NodeJS.ReadableStream | Buffer, { createFolders, mode }?: {
        createFolders?: boolean;
        mode?: number;
    }): Archiver;
    remove(pth: string): Archiver;
    private get _finalizer();
    finalize(): Promise<{
        details: () => Promise<{
            buffer: Buffer;
            contentLength: number;
            name: string;
        }>;
        nodeStream: () => Promise<NodeJS.ReadableStream>;
        fsStream: () => Promise<{
            stream: ReadStream;
            length: number;
        }>;
        writeZip: (pth: string) => Promise<void>;
    }>;
}
export default Archiver;
