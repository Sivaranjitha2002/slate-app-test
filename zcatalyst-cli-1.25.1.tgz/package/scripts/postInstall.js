#!/usr/bin/env node
/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/no-var-requires */

'use strict';

try {
	const semver = require('semver');
	const ansi = require('ansi-colors');
	const cliTable = require('../lib/cli_table');
	const packageJson = require('../package.json');

	const promise = new Promise(async (res) => {
		if (semver.satisfies(process.version, packageJson.engines.node)) {
			console.log(ansi.green.bold('Installation successful.'));
			return res(0);
		}

		const table = new cliTable({ style: { border: [], header: [] } });
		table.push(
			{
				'Current version: ': [ansi.red(semver.clean(process.version))]
			},
			{
				'Compatible version: ': [ansi.green(packageJson.engines.node)]
			}
		);
		console.error(ansi.red('Node.js version is incompatible !!!'));
		console.error(table.toString());
		console.error('\n' + ansi.yellow.bold('Please update Node.js to a compatible version.'));
		console.error(ansi.bold('Reference: ') + ansi.underline('https://nodejs.org/') + '\n');
		res(1);
	});

	promise.then(
		(code) => process.exit(code),
		() => process.exit(1)
	);
} catch (err) {
	console.error(err);
}
