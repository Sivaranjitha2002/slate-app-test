'use strict';
import Cliq from 'zcatalyst-integ-cliq';
const linkPreviewHandler = Cliq.linkPreviewHandler();

linkPreviewHandler.previewHandler(async (req, res) => {
    res.title = 'Release checklist | Zoho Cliq';
    res.type = 'link';
    res.provider_url = 'https://www.zoho.com/cliq/';
    res.description = 'Release checklist for Cliq 5.0 (Focused on Enterprise and Intelligence)';
    res.dynamic_actions = true;

    let fields = res.newOembedFields();
    let fieldsData = [];
    fieldsData.push(fields.newOembedFieldData('Created By','Scott fisher'));
    fieldsData.push(fields.newOembedFieldData('Created On', '10 Aug, 2023'));
    fieldsData.push(fields.newOembedFieldData('Last Modified On', '11 Aug, 2023'));
    fieldsData.push(fields.newOembedFieldData('Tags', '#unfurling_via_extensions #images_and_cards #cliq_360 #Cliq_5.0'));
    fields.data = fieldsData;
    res.fields = fields;

    let actions = [];
    const action = res.newOembedActions();
    action.type = 'button';
    action.label = 'Add Comment';
    const confirm = action.newConfirm();
    confirm.title = 'Comment';
    confirm.description = 'Add your comment to the notes';
    confirm.input = 'Type here...';
    action.confirm = confirm;
    let params = {'action': 'add_comment'};
    action.params = params;
    actions.push(action);
    res.actions = actions;

    return res;
});

linkPreviewHandler.actionHandler(async (req, res) => {
    const action = req.target.params.action;
    let text;
    if(action === "add_comment")
	{
		text = "Your comment has been added successfully";
	}
	else if(action === "delete_note")
	{
		text = "Release checklist | Zoho Cliq note has been deleted";
	}
	else if(action === "mark_as_favorite")
	{
		text = "Release checklist | Zoho Cliq note has been marked as favorite";
	}
    return res.newBanner(text,'success');
});

linkPreviewHandler.menuHandler(async (req, res) => {
		
    let action1 = linkPreviewHandler.newOembedActions('button');
    action1.label = 'Delete';
    action1.params = {'action': 'delete_note'};
    res.push(action1);

    let action2 = linkPreviewHandler.newOembedActions('button');
    action2.label = 'Mark as Favorite';
    action2.params = {'action': 'mark_as_favorite'};
    res.push(action2);

    return res;
});

linkPreviewHandler.afterSendHandler(async (req, res) => {
    return res.newBanner('Release checklist | Zoho Cliq 5.0','success');
});