/**
 * 
 * @param {import('./types/cron').CronDetails} cronDetails 
 * @param {import('./types/cron').Context} context 
 */
module.exports = (cronDetails, context) => {
	console.log('Hello from {{_MAIN_}}');

	// let cronParams = cronDetails.getCronParam('');
	// let remainingExecutionCount = cronDetails.getRemainingExecutionCount();
	// let thisCronDetails = cronDetails.getCronDetails();
	// let projectDetails = cronDetails.getProjectDetails();

	// let remainingTime = context.getRemainingExecutionTimeMs();
	// let executionTime = context.getMaxExecutionTimeMs();

	/* 
        CONTEXT FUNCTIONALITIES
    */
	context.closeWithSuccess(); //end of application with success
	// context.closeWithFailure(); //end of application with failure
};
