
// Read the `url` from request, goto the page, extract title and return the results

module.exports.puppeteer = async (request, response, page) => {
    await page.goto('https://catalyst.zoho.com',{waitUntil: "domcontentloaded"});
    const pageTitle = await page.title();
    response.setHeader('Content-Type', 'application/json');
    response.write(JSON.stringify({ output: pageTitle }));
    response.end();
};
