//$Id$
package com.handlers;

import com.zc.cliq.enums.EXTENSION_TYPE;
import com.zc.cliq.enums.STATUS;
import com.zc.cliq.objects.InstallationResponse;
import com.zc.cliq.requests.ExtensionHandlerRequest;

public class ExtensionHandler implements com.zc.cliq.interfaces.ExtensionHandler{

	@Override
	public InstallationResponse validateInstallation(ExtensionHandlerRequest req) throws Exception {
		InstallationResponse resp = InstallationResponse.getInstance();
		if (req.getUser().getFirstName().equals("**INVALID_USER**") && req.getAppInfo().getType().equals(EXTENSION_TYPE.UPGRADE)) {
			resp.setStatus(STATUS.FAILURE);
			resp.setTitle("Update not allowed !");
			resp.setMessage("Sorry. Update not allowed for the current app. Please contact admin.");
		} else {
			resp.setStatus(STATUS.SUCCESS);
		}
		return resp;
	}

	@Override
	public InstallationResponse handleInstallation(ExtensionHandlerRequest req) throws Exception {
		InstallationResponse resp = InstallationResponse.getInstance();
		/*
		 * // Logic for installation post handling {
		 * 
		 * }
		 */
		resp.setStatus(STATUS.SUCCESS);
		return resp;
	}
	
	@Override
	public void handleUninstallation(ExtensionHandlerRequest req) throws Exception {
		// Logic for uninstallation post handling
	}

}
