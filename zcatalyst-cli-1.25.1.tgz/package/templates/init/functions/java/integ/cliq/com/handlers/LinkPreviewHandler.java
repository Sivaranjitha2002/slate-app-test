//$Id$
package com.handlers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.zc.cliq.enums.BANNER_STATUS;
import com.zc.cliq.enums.OEMBED_ACTION_TYPE;
import com.zc.cliq.enums.OEMBED_TYPES;
import com.zc.cliq.objects.Confirm;
import com.zc.cliq.objects.OembedActions;
import com.zc.cliq.objects.OembedFieldData;
import com.zc.cliq.objects.OembedFields;
import com.zc.cliq.requests.LinkPreviewHandlerRequest;
import com.zc.cliq.responses.BannerResponse;
import com.zc.cliq.responses.CoreResponse;
import com.zc.cliq.responses.UnfurlResponse;

public class LinkPreviewHandler implements com.zc.cliq.interfaces.LinkPreviewHandler {

	@Override
	public UnfurlResponse previewHandler(LinkPreviewHandlerRequest req) throws Exception {
		UnfurlResponse response = new UnfurlResponse("Release checklist | Zoho Cliq", OEMBED_TYPES.LINK, "https://www.zoho.com/cliq/");
		response.setDescription("Release checklist for Cliq 5.0 (Focused on Enterprise and Intelligence)");
		response.setDynamicActions(true);

		// Create fields
		List<OembedFieldData> fieldsData = new ArrayList<>();
		fieldsData.add(new OembedFieldData("Created By","Scott fisher"));
		fieldsData.add(new OembedFieldData("Created On", "10 Aug, 2023"));
		fieldsData.add(new OembedFieldData("Last Modified On", "11 Aug, 2023"));
		fieldsData.add(new OembedFieldData("Tags", "#unfurling_via_extensions #images_and_cards #cliq_360 #Cliq_5.0"));

		OembedFields fields = new OembedFields(null, fieldsData);
		response.setFields(fields);

		// Create actions
		List<OembedActions> actions = new LinkedList<OembedActions>();
		OembedActions action = new OembedActions(OEMBED_ACTION_TYPE.BUTTON, "Add Comment");
		
		Confirm confirm = new Confirm();
		confirm.setTitle("Comment");
		confirm.setDescription("Add your comment to the notes");
		confirm.setInput("Type here...");
		action.setConfirm(confirm);
		
		HashMap<String,Object> params = new HashMap<String,Object>();
		params.put("action", "add_comment");
		action.setParams(params);
		
		actions.add(action);
		
		response.setActions(actions);
		return response;
	}
	
	@Override
	public CoreResponse actionHandler(LinkPreviewHandlerRequest req) throws Exception {
		HashMap<String,Object> target = (HashMap<String, Object>) req.getTarget();
		HashMap<String,Object> params = (HashMap<String, Object>) target.get("params");
		String action = (String) params.get("action");
		String text = null;
		if(action.equals("add_comment"))
		{
			text = "Your comment has been added successfully";
		}
		else if(action.equals("delete_note"))
		{
			text = "Release checklist | Zoho Cliq note has been deleted";
		}
		else if(action.equals("mark_as_favorite"))
		{
			text = "Release checklist | Zoho Cliq note has been marked as favorite";
		}
		BannerResponse banner = new BannerResponse(text, BANNER_STATUS.SUCCESS);
		return banner;

	}

	@Override
	public List<OembedActions> menuHandler(LinkPreviewHandlerRequest req) throws Exception {
		List<OembedActions> actions = new LinkedList<OembedActions>();
		
		OembedActions delete = new OembedActions(OEMBED_ACTION_TYPE.BUTTON,"Delete");
		HashMap<String,Object> deleteParam = new HashMap<String,Object>();
		deleteParam.put("action", "delete_note");
		delete.setParams(deleteParam);
		actions.add(delete);
		
		OembedActions favorite = new OembedActions(OEMBED_ACTION_TYPE.BUTTON, "Mark as Favorite");
		HashMap<String,Object> favoriteParams = new HashMap<String,Object>();
		favoriteParams.put("action", "mark_as_favorite");
		favorite.setParams(favoriteParams);
		actions.add(favorite);
		
		return actions;
		
	}
	
	@Override
	public CoreResponse afterSendHandler(LinkPreviewHandlerRequest req) throws Exception {
		BannerResponse banner = new BannerResponse("Release checklist | Zoho Cliq 5.0", BANNER_STATUS.SUCCESS);
		return banner;
	}	

}
