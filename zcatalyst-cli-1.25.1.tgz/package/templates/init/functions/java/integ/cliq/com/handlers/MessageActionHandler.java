//$Id$
package com.handlers;

import com.zc.cliq.enums.MESSAGE_TYPE;
import com.zc.cliq.objects.Message;
import com.zc.cliq.requests.MessageActionHandlerRequest;
import com.zc.cliq.responses.CoreResponse;

public class MessageActionHandler implements com.zc.cliq.interfaces.MessageActionHandler {
	@Override
	public CoreResponse executionHandler(MessageActionHandlerRequest req) throws Exception {
		MESSAGE_TYPE msgType = req.getMessage().getType();
		String firstName = req.getUser() != null ? req.getUser().getFirstName() : "user";

		String text = "Hey " + firstName + ", You have performed an action on a *" + msgType.getType() + "*. Manipulate the message variable and perform your own action.";

		Message resp = Message.getInstance();
		resp.setText(text);

		return resp;
	}

}
