import java.util.logging.Logger;

import com.catalyst.integ.CatalystIntegFunctionHandler;
import com.catalyst.integ.ZCIntegRequest;
import com.catalyst.integ.ZCIntegResponse;
import com.zc.cliq.util.ZCCliqUtil;

public class {{_CLASS_}} implements CatalystIntegFunctionHandler {
	Logger LOGGER = Logger.getLogger({{_CLASS_}}.class.getName());

	@Override
	public ZCIntegResponse runner(ZCIntegRequest req) throws Exception {
		try {
			ZCIntegResponse resp =  ZCCliqUtil.executeHandler(req);
			return resp;
		} catch(Exception ex) {
			LOGGER.severe("Exception while executing handler.");
			throw ex;
		}
	}
}

/*
 * Response type supported by these interface:
 * 		CoreResponse: BannerResponse,Message,PreviewUrlResponse,Form,VoidResponse
 * 		FormChangeHandlerResponse: FormChangeHandlerResponse, FormError
 * 		FormSubmitResponse: BannerResponse,Message,PreviewUrlResponse,Form,FormError,WidgetResponse,WidgetSection,VoidResponse
 * 		WebhookHandlerResponse: Message,WebhookResponse,VoidResponse
 * 		WidgetButtonResponse: BannerResponse,PreviewUrlResponse,Form,WidgetResponse,WidgetSection,VoidResponse
 * 		ButtonFunctionResponse: BannerResponse,Message,PreviewUrlResponse,Form,WidgetResponse,WidgetSection,VoidResponse
 */