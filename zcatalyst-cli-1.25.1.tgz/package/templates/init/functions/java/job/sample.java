import java.util.logging.Level;
import java.util.logging.Logger;

import com.catalyst.Context;
import com.catalyst.job.JOB_STATUS;
import com.catalyst.job.JobRequest;
import com.catalyst.job.CatalystJobHandler;

 import com.zc.common.ZCProject;
 import com.zc.component.cache.ZCCache;

public class {{_CLASS_}} implements CatalystJobHandler {

	private static final Logger LOGGER = Logger.getLogger({{_CLASS_}}.class.getName());

	@Override
	public JOB_STATUS handleJobExecute(JobRequest request, Context arg1) throws Exception {
		try {
			ZCProject.initProject();
			Object eventData = request.getAllJobParams();
			if(eventData != null) {
				LOGGER.log(Level.SEVERE, "Data is" + eventData.toString());
			}
			LOGGER.log(Level.SEVERE, "Project Details " + request.getProjectDetails().toString());
			ZCCache.getInstance().putCacheValue("JobSample", "Working", 1l);
			LOGGER.log(Level.SEVERE, "Inserted SuccessFully:)");
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception in Job Function", e);
			return JOB_STATUS.FAILURE;
		}
		return JOB_STATUS.SUCCESS;
	}

}
