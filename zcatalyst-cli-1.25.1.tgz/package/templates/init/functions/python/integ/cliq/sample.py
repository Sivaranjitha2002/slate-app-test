import zcatalyst_cliq

config = {
    "ZohoCliq": {{__INTEG_HANDLERS__}}
}

def handler(request, response):
    handler_resp = zcatalyst_cliq.execute(request, config)
    response.set_content_type('application/json')
    response.send(handler_resp)
