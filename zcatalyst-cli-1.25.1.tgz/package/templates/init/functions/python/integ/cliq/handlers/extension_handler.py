from zcatalyst_cliq.extension_handler import validate_installation, ExtensionHandlerRequest, handle_installation, \
    handle_uninstallation
from zcatalyst_cliq.response_types import InstallationResponse, VoidResponse


@validate_installation
def validate_installation(req: ExtensionHandlerRequest,res: InstallationResponse, *args):
    if req.user.first_name == '**INVALID_USER**' and req.app_info.type == 'upgrade':
        res.status = 400
        res.title = 'Update not allowed !'
        res.message = 'Sorry. Update not allowed for the current app. Please contact admin.'
    else:
        res.status = 200
    return res

@handle_installation
def installation_handler(req: ExtensionHandlerRequest, res: InstallationResponse, *args):
    '''Logic for installation post handling'''
    res.status = 200
    return res

@handle_uninstallation
def handle_uninstallation(req: ExtensionHandlerRequest, res: VoidResponse, *args):
    # Logic for uninstallation post handling
    return res