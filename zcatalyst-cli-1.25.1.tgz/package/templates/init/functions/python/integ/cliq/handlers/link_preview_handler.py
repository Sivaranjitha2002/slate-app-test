from typing import List

from zcatalyst_cliq.handler_response import HandlerResponse
from zcatalyst_cliq.link_preview_handler import (preview_handler, LinkPreviewHandlerRequest, action_handler,
                                                 menu_handler, after_send_handler, new_oembed_actions)
from zcatalyst_cliq.response_types import UnfurlResponse, OembedActions, OembedFieldData


@preview_handler
def preview_handler(req: LinkPreviewHandlerRequest,res: UnfurlResponse):
    res.type = 'link'
    res.title = 'Release checklist | Zoho Cliq'
    res.provider_url = 'https://www.zoho.com/cliq/'
    res.description = 'Release checklist for Cliq 5.0 (Focused on Enterprise and Intelligence)'
    res.dynamic_actions = True

    fields = res.new_oembed_fields()
    fieldsData: List[OembedFieldData] = list()
    fieldsData.append(fields.new_oembed_field_data('Created By', 'Scott fisher'))
    fieldsData.append(fields.new_oembed_field_data('Created On', '10 Aug, 2023'))
    fieldsData.append(fields.new_oembed_field_data('Last Modified On', '11 Aug, 2023'))
    fieldsData.append(fields.new_oembed_field_data('Tags', '#unfurling_via_extensions #images_and_cards #cliq_360 #Cliq_5.0'))
    fields.data = fieldsData
    res.fields = fields

    actions: List[OembedActions] = list()
    action = res.new_oembed_actions()
    action.type = 'button'
    action.label = 'Add Comment'

    confirm = action.new_confirm()
    confirm.title = 'Comment'
    confirm.description = 'Add your comment to the notes'
    confirm.input = 'Type here...'
    action.confirm = confirm

    params = {'action': 'add_comment'}
    action.params = params
    actions.append(action)
    res.actions = actions

    return res

@action_handler
def action_handler(req: LinkPreviewHandlerRequest,res: HandlerResponse):
    target: dict = vars(req.target)
    params = vars(target.get('params'))
    action = params.get('action')
    text = ""
    if action == "add_comment":
        text = "Your comment has been added successfully"
    elif action == "delete_note":
        text = "Release checklist | Zoho Cliq note has been deleted"
    elif action == "mark_as_favorite":
        text = "Release checklist | Zoho Cliq note has been marked as favorite"
    return res.new_banner(text,'success')

@menu_handler
def menu_handler(req: LinkPreviewHandlerRequest,res: List[OembedActions]):
    action1 = new_oembed_actions()
    action1.type = 'button'
    action1.label = 'Delete'
    action1.params = {'action': 'delete_note'}

    action2 = new_oembed_actions()
    action2.type = 'button'
    action2.label = 'Mark as Favorite'
    action2.params = {'action': 'mark_as_favorite'}
    res.extend([action1,action2])

    return res


@after_send_handler
def after_send_handler(req: LinkPreviewHandlerRequest,res: HandlerResponse):
    return res.new_banner("Release checklist | Zoho Cliq 5.0','success")