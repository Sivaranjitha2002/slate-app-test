import logging


def handler(job_request, context):
    logger = logging.getLogger()
    logger.info('Hello from {{_MAIN_}}')

    # function input: { job_details: { job_meta_details: { params: { key: 'value' } } } }

    '''JobRequest Functionalities'''
    job_details = job_request.get_job_details() # get the details of the current job
    project_details = job_request.get_project_details() # get the details of the current project
    job_meta_details = job_request.get_job_meta_details() # get the job meta of the current job
    job_capacity_attributes = job_request.get_job_capacity_attributes() # get the current jobs capacity
    all_job_params = job_request.get_all_job_params() # get all the parameters supplied to the job function
    job_param = job_request.get_job_param('key') # get the value of a particular parameter supplied to the job function

    '''Context Functionalities'''
    remaining_execution_time_ms = context.get_remaining_execution_time_ms() # get the maximum allowed execution time for the job functions
    max_execution_time_ms = context.get_max_execution_time_ms() # get the remaining execution time for this job function
    # context.close_with_failure() # conclude the function execution with a failure response
    context.close_with_success() # conclude the function execution with a success response
