def handler(context, basicio):
    basicio.write('Hello from {{_MAIN_}}')
    basicio.get_argument('name')

    context.log('Successfully executed basicio function')
    context.close()
