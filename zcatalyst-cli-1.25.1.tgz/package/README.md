<center>
    <a href="https://catalyst.zoho.com/">
        <img width="150" src="https://static.zohocdn.com/catalyst-cdn/img/Catalyst-Logo-857518f26c.svg">
    </a>
<h1>Catalyst CLI</h1>
</center>

<p>
  The official command line interface of Zoho Catalyst
</p>
<br>

![catalyst](https://img.shields.io/badge/%E2%9A%A1-catalyst-blue.svg)
![npm](https://img.shields.io/npm/v/zcatalyst-cli.svg?color=blue)
![NPM](https://img.shields.io/npm/l/zcatalyst-cli.svg?color=brightgreen)
<br>

<img align="right" width="350" src="https://static.zohocdn.com/catalyst-cdn/img/getstartedcli-bb68093919.gif"/>

This is the Catalyst Command Line Interface (CLI) Tool. They can be used to:

- Initialize your project and associate it with various components
- Create and manage your projects
- Interact with data in your Catalyst projects via console
- Deploy code and assets to your Catalyst projects

To get started with the Catalyst CLI, you can go through our documentation  [CLI documentation](https://docs.catalyst.zoho.com/en/cli/v1/cli-command-reference/).

## Installation

To install the Catalyst CLI, you first need to [Sign Up](https://accounts.zoho.com/) to ZOHO.

Then you need to install [Node.js](http://nodejs.org/) and [npm](https://npmjs.org/).

---
**NOTE**

1. Installing Node.js should install npm as well.
2. The ZCatalyst-CLI is compatible only with node versions >=14.

---

Once npm is installed, you can get Catalyst CLI via following command:

```bash
npm install -g zcatalyst-cli
```

This will provide you with the globally accessible `catalyst` command.

---

**NOTE**

1. If you need to setup the cli in current directory alone use the same command without `-g` option.

2. Alternatively you can visit [CLI Installation Documentation](https://docs.catalyst.zoho.com/en/getting-started/installing-catalyst-cli/) for installation instructions.

---

## Commands

**The command `catalyst --help` lists all the available commands and `catalyst <command> --help` shows more details for provided command (if exists).**

Certain command are project specific and for it to work you must be inside a project directory or you can simply specify the project id via `-p <project_id>` option.

### List of the available commands

Command | Description
------- | -----------
**help** | Display the command reference or help for a specific command.
**login** | Log the CLI in to your Catalyst account. *Requires access to a web browser*.
**whoami** | Print the email address of the user currently logged in.
**token:generate** | Generate a token to authenticate accessing the CLI from a remote system.
**token:revoke** | Revoke a token generated in this CLI.
**token:list** | List all the available tokens generated in this CLI.
**project:list** | List all the Catalyst projects you have access to.
**project:use** | Set an active Catalyst project for your working directory.
**project:reset** | Clear an active project selection and reset to the base project.
**init** | Initialize a Catalyst project, function, and client resources in the local directory.
**pull** | Pull resources of your project from the remote console to the local directory.
**iac:pack** | Creates a import ready zip file.
**iac:import** | Deploy the iac zip file to console and create a new project with it.
**iac:export** | Create a zip file out of existing project in console.
**iac:status** | Displays the status of iac schedule progress.
**apig:status** | Obtain the current status of API Gateway for your project and the schedule progress.
**apig:enable** | Enable API Gateway for your project. *In both Console and Local*.
**apig:disable** | Disable API Gateway for your project. *In both Console and Local*.
**ds:import** | Bulk write records to a table in the Catalyst Data Store.
**ds:export** | Bulk read records from a table in the Catalyst Data Store.
**ds:status** | Display the job status of a Data Store import or export operation.
**client:setup** | Set up and configure the client directory in your project directory.
**client:delete** | Delete a version of the client from the remote console or the local directory.
**functions:setup** | Set up and configure the function directory in your project directory.
**functions:add** | Add a function of the required stack to the function directory.
**functions:shell** | Launch a node shell to test emulated functions of any stack or type, other than Advanced I/O functions.
**functions:config** | Perform advanced configurations such as memory allocation on a function in your project.
**functions:delete** | Delete a function from the remote console or the local directory.
**appsail:add** | Link an already existing AppSail app to Catalyst Project.
**slate:create** | Generates a new Slate app with starter examples.
**slate:link** | Links an existing local app to the Catalyst Slate service.
**slate:unlink** | Removes the linked Slate configuration from the local app.
**codelib:install** | Install the code library functionalities into your project.
**event:generate \| generate:event** | Generate sample payloads from different components or custom event sources to test Event functions.
**event:generate:integ** | Generate sample payloads for the required integration service to test Integration functions.
**event:generate:job** | Generate sample payloads to test the job functions.
**serve** | Serve Basic I/O and Advanced I/O functions, and the client, to test them locally.
**deploy** | Deploy the Catalyst project and project resources to the remote console from the local directory.
**run-script \| run** | Run a particular command script defined in *catalyst.json*.
**config:set** |  Set catalyst configuration as a key value pair.
**config:get** |  Get catalyst config value for the specified key.
**config:delete** |  Delete a key from catalyst config.
**config:list** |  List all your catalyst configurations.
**logout** |  Log the CLI out of your Catalyst account.


---

## Migration

Migration will run for every new version of CLI when executing a command with proper scopes.

This is to make sure your local project is upto date with the CLI version that is updated.

### **v1.4.0**

- Global configuration file (zcatalyst-cli-nodejs/zcatalyst-cli.json) structure change.

### **v1.6.2**

- Global configuration file (zcatalyst-cli-nodejs/zcatalyst-cli.json) structure change.
